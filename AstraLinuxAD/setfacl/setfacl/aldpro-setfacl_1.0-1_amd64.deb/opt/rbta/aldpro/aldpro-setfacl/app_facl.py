"""
    Модуль для добавления субъектов домена в ACL
"""

import subprocess
import json
from tkinter import messagebox

import app_messages as messages
import app_logging

logger = app_logging.logger

def subject_exists_in_alc(is_user: bool, subject_id: int, object_path: str):
    """ Функция проверяет наличие субъекта в ACL """

    result = subprocess.run(f'getfacl -n \'{object_path}\' | grep -v "#"', capture_output=True, text=True, shell=True)
    
    if result.returncode != 0:
        logger.error(result.stderr)
        messagebox.showerror(title=messages.app_error_title,
            message=result.stderr,
            icon='info')
        return False

    acl_subjects = []

    acl_subject_type = 'user' if is_user else 'group'

    for acl_record in result.stdout.splitlines():
        record_elements = acl_record.split(':')
        try:
            if record_elements[0] == acl_subject_type:            
                acl_subjects.append(int(record_elements[1]))
        except:
            pass

    return subject_id in acl_subjects

def add_to_acl(subject_list: list, object_path: str):
    """ Функция добавляет субъект в ACL без прав доступа """

    for item in subject_list:
        try:
            subject = json.loads(item)

            uidNumber = subject.get('uidNumber')
            if uidNumber:
                is_user = True
                subject_type = 'u'
                subject_id = uidNumber

            gidNumber = subject.get('gidNumber')
            if gidNumber:
                is_user = False
                subject_type = 'g'
                subject_id = gidNumber
            
            if subject_exists_in_alc(is_user, int(subject_id), object_path):
                logger.info(messages.facl_subject_already_exists.replace("%SUBJECT_ID%", str(subject_id)))
            else:
                result = subprocess.run(f'setfacl -n -m "{subject_type}:{subject_id}:---" \'{object_path}\'', capture_output=True, text=True, shell=True)                
                if result.returncode == 0:
                    logger.info(messages.facl_subject_added_successfully.replace("%SUBJECT_ID%", subject_id))
                else:
                    logger.error(messages.facl_subject_adding_failed.replace("%SUBJECT_ID%", subject_id))
                
        except:
            pass

    return True