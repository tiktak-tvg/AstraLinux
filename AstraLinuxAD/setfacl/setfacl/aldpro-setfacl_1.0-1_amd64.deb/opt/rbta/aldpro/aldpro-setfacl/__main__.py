#!/usr/bin/python3

from sys import argv
import os
import subprocess
from subprocess import PIPE
import tkinter as tk
import tkinter.ttk as ttk
from tkinter import messagebox
from Xlib import X, display, XK, ext
import time
import json

from app_facl import add_to_acl
from app_krb5 import check_krb5_keys, get_krb5_keys
from app_ldap import ldap_search_subjects
import app_messages as messages
import app_logging


logger = app_logging.logger
project_path = os.path.abspath(os.path.dirname(__file__))

#Путь до редактируемого объекта файловой системы
if len(argv)>1:
    object_path = ' '.join(argv[1:])
else:
    object_path = os.getenv("HOME")

def place_window_center(window):
    """ Функция размещает окно по центру """
    
    window.update_idletasks()
    x = (window.winfo_screenwidth() - window.winfo_width()) // 2
    y = (window.winfo_screenheight() - window.winfo_height()) // 2
    window.geometry(f"+{x}+{y}")

class SetFACL:
    def __init__(self, master=None):
        self.main_window = tk.Tk() if master is None else tk.Toplevel(master, container='false')

        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.style.configure('.', font=('Segoe', 10))

        self.main_window.title(messages.app_title)
        self.main_window.iconphoto(True, tk.PhotoImage(file=f'{project_path}/astra.gif'))
        self.main_window.resizable(False, False)
        self.main_window.geometry("300x460") 
        self.main_window.update()
        self.main_window.bind('<KeyRelease-Return>', lambda e: self.search_handler())
        self.main_window.bind('<KeyRelease-Escape>', lambda e: self.main_window.destroy())
        place_window_center(self.main_window)        

        ttk.Label(self.main_window, text=messages.object_path).pack(fill=tk.X, padx=10, pady=[10, 0])
        self.entry_object_path = ttk.Entry(self.main_window)
        self.entry_object_path.pack(fill=tk.X, padx=10, pady=[3, 5])
        self.entry_object_path.insert(0, object_path)
        self.entry_object_path.configure(state='readonly')

        self.frame_subject_type = ttk.Frame(self.main_window, borderwidth=1, relief="raised")
        self.frame_subject_type.pack(fill=tk.X, expand=True, padx=10, pady=5)
        
        ttk.Label(self.frame_subject_type, text=messages.select_subject_type, anchor="center").pack(fill=tk.X, padx=10, pady=5)

        self.var_is_user = tk.BooleanVar()
        self.var_is_user.set(True)
        self.var_previous_radio_status = self.var_is_user.get()

        self.rbtn_subject_user = ttk.Radiobutton(self.frame_subject_type, command=self.change_subject_type)
        self.rbtn_subject_user.configure(text=messages.subject_type_user, variable=self.var_is_user, value=True)
        self.rbtn_subject_user.pack(side='left', padx=20, pady=5)

        self.rbtn_subject_group = ttk.Radiobutton(self.frame_subject_type, command=self.change_subject_type)
        self.rbtn_subject_group.configure(text=messages.subject_type_group, variable=self.var_is_user, value=False)
        self.rbtn_subject_group.pack(side='right', padx=20, pady=5)

        self.frame_found_items = ttk.Frame(self.main_window, borderwidth=1, relief="raised")
        self.frame_found_items.pack(fill=tk.X, expand=True, padx=10)

        self.label_found_items = ttk.Label(self.frame_found_items)
        self.label_found_items.configure(borderwidth='5', text=messages.select_subject)
        self.label_found_items.pack(side='top')

        self.scrollbar_found_items = ttk.Scrollbar(self.frame_found_items)
        self.scrollbar_found_items.pack(side=tk.RIGHT, fill=tk.Y, pady=[0, 35])
        self.treeview_found_items = ttk.Treeview(self.frame_found_items, show="tree", yscrollcommand=self.scrollbar_found_items.set)
        self.scrollbar_found_items.config(command=self.treeview_found_items.yview)
        self.treeview_found_items.configure(yscroll=self.scrollbar_found_items.set)
        self.treeview_found_items.pack(side='top', fill=tk.X, padx=[10, 0])
        
        self.frame_search = ttk.Frame(self.frame_found_items)
        self.frame_search.pack(side='top', padx=[10, 0])

        self.entry_search = ttk.Entry(self.frame_search)
        self.entry_search.configure()
        self.entry_search.delete('0', 'end')
        self.entry_search.insert('0', messages.search_placeholder)
        self.entry_search.pack(side='left')
        self.entry_search.bind("<FocusIn>", self.on_focus)
        self.entry_search.bind("<FocusOut>", self.on_blur)
        
        self.button_search = ttk.Button(self.frame_search, padding=1)
        self.button_search.configure(state='normal', text=messages.search_button, command=lambda: self.search_handler())
        self.button_search.pack(side='right', padx=2, pady=5)

        self.frame_action_buttons = ttk.Frame(self.main_window, padding=10)
        self.frame_action_buttons.pack(side='bottom', fill='x', expand=True, ipadx=8)

        self.button_cancel = ttk.Button(self.frame_action_buttons)
        self.button_cancel.configure(text=messages.cancel_button, command=lambda: self.main_window.destroy())
        self.button_cancel.pack(side='right')

        self.button_ok = ttk.Button(self.frame_action_buttons)
        self.button_ok.configure(text=messages.ok_button, command=lambda: self.ok_handler(), state="disabled")
        self.button_ok.pack(expand='false', side='right', padx=5)


    def search_handler(self):

        self.button_ok.config(state="disabled")

        #Очищаем список 
        for item in self.treeview_found_items.get_children():
            self.treeview_found_items.delete(item)

        #Выполняем аутентификацию, если она еще не пройдена
        if not check_krb5_keys():
            self.main_window.wait_window(GetKerberosKeys(self.main_window))
            if not check_krb5_keys():
                return
        
        #Выполняем поиск
        self.subject_list = ldap_search_subjects(self.entry_search.get(), self.var_is_user.get())
        
        #Выходим из обработчика, если нет результатов для отображения
        if self.subject_list == None or len(self.subject_list)==0:
            return

        if self.var_is_user.get():
            search_attr = "uid"
        else:
            search_attr = "cn"

        for item in self.subject_list:
            self.treeview_found_items.insert(
                parent="", 
                index="end", 
                iid=json.JSONEncoder().encode(item), 
                text=item.get(search_attr))
        
        #Выделим первый элемент в списке        
        tree = self.treeview_found_items        
        children = tree.get_children()
        if children:
            tree.selection_set(children[0])
            self.button_ok.config(state="normal")


    def ok_handler(self):
        
        if not os.path.exists(object_path):
            messagebox.showerror(title=messages.app_error_title,
                message=messages.object_path_error.replace("%FILENAME%", object_path),
                icon='info')
            return

        if not (add_to_acl(subject_list=self.treeview_found_items.selection(), object_path=object_path)):
            return

        ask_to_continue = messagebox.askquestion(title=messages.ask_to_continue_title, 
            message=messages.ask_to_continue_text,
            icon='info')
        
        if ask_to_continue == 'yes':
            
            proc = subprocess.Popen(["/usr/bin/fly-props", "-s", object_path], stdout=PIPE, stderr=PIPE)
            proc_pid = proc.pid

            d = display.Display()
            root = d.screen().root

            retries = 10
            window_id = False
            while window_id == False:
                for window in root.query_tree().children:
                    window_pid = window.get_full_property(d.intern_atom('_NET_WM_PID'), X.AnyPropertyType)
                    if proc_pid in window_pid.value:
                        window_id = window.id
                if retries == 0:
                    break
                else:
                    retries = retries - 1
                    time.sleep(0.1)

            if window_id == False:
                return

            window = d.create_resource_object('window', window_id)
            window.change_attributes(event_mask=0, input=False)
            window.set_input_focus(X.RevertToParent, X.CurrentTime)

            tab_key = d.keysym_to_keycode(XK.XK_Tab)
            ctrl_key = d.keysym_to_keycode(XK.XK_Control_L)
            right_arrow_key = d.keysym_to_keycode(XK.XK_Right)

            if not ext.xtest:
                logger.error(messages.xtest_error)
                exit()                    

            else:

                if os.path.isfile(object_path):
                    ext.xtest.fake_input(d, X.KeyPress, tab_key) 
                    ext.xtest.fake_input(d, X.KeyRelease, tab_key)

                    time.sleep(0.5)

                    ext.xtest.fake_input(d, X.KeyPress, ctrl_key)  
                    ext.xtest.fake_input(d, X.KeyPress, right_arrow_key)  
                    ext.xtest.fake_input(d, X.KeyRelease, right_arrow_key) 
                    ext.xtest.fake_input(d, X.KeyRelease, ctrl_key) 
                
                if os.path.isdir(object_path):
                    ext.xtest.fake_input(d, X.KeyPress, tab_key) 
                    ext.xtest.fake_input(d, X.KeyRelease, tab_key)                        

                    time.sleep(0.5)

                    ext.xtest.fake_input(d, X.KeyPress, ctrl_key)  
                    ext.xtest.fake_input(d, X.KeyPress, right_arrow_key)  
                    ext.xtest.fake_input(d, X.KeyRelease, right_arrow_key) 
                    ext.xtest.fake_input(d, X.KeyRelease, ctrl_key) 

                    ext.xtest.fake_input(d, X.KeyPress, ctrl_key)  
                    ext.xtest.fake_input(d, X.KeyPress, right_arrow_key)  
                    ext.xtest.fake_input(d, X.KeyRelease, right_arrow_key) 
                    ext.xtest.fake_input(d, X.KeyRelease, ctrl_key)

                d.flush()

    def run(self):
        self.main_window.mainloop()

    def on_focus(self, event):
        """ Очищаем текстовое поле, если оно содержит текст по умолчанию """

        if self.entry_search.get() == messages.search_placeholder:
            self.entry_search.delete(0, 'end')

    def on_blur(self, event):
        """ Устанавливаем текст по умолчанию, если значение не задано """

        if self.entry_search.get() == '':
            self.entry_search.insert(0, messages.search_placeholder)

    def change_subject_type(self):
        """ Очищаем список найденных объектов при изменении типа субъекта """

        if self.var_previous_radio_status != self.var_is_user.get():

            self.var_previous_radio_status = self.var_is_user.get()
            
            self.button_ok.config(state="disabled")

            for item in self.treeview_found_items.get_children():
                self.treeview_found_items.delete(item)

            if self.entry_search.get() != messages.search_placeholder:
                self.search_handler()

class GetKerberosKeys(tk.Toplevel):
    """ Окно аутентификации """
    
    def __init__(self, parent):
        super().__init__(parent)

        #Открываем форму в модальном режиме
        self.grab_set()


        self.geometry("300x120") 
        self.resizable(width = False, height = False)
        self.title(messages.krb_title)

        self.style = ttk.Style()
        self.style.theme_use('clam')

        self.frame_krb = ttk.Frame(self)
        self.label_krb = ttk.Label(self.frame_krb)
        self.label_krb.configure(borderwidth='5', text=messages.krb_enter_password)
        self.label_krb.pack()

        self.entry_krb = ttk.Entry(self.frame_krb, width=30)
        self.entry_krb.configure()
        self.entry_krb.delete('0', 'end')
        self.entry_krb['show'] = '*'
        self.entry_krb.focus_set()
        self.entry_krb.pack(padx=5)

        self.button_krb_cancel = ttk.Button(self.frame_krb)
        self.button_krb_cancel.configure(text=messages.krb_cancel_button, command=lambda: self.destroy())
        self.button_krb_cancel.pack(expand='false', padx=20, pady=10, side='right')
        self.button_krb_cancel.pack_propagate(0)

        self.button_krb_ok = ttk.Button(self.frame_krb)
        self.button_krb_ok.configure(state='normal', text=messages.krb_ok_button, command=lambda: self.submit())
        self.button_krb_ok.pack(expand='false', padx=20, pady=10, side='right')
        self.button_krb_ok.pack_propagate(0)

        self.frame_krb.pack(side='top')

        self.bind('<KeyRelease-Return>', lambda e: self.submit())
        self.bind('<KeyRelease-Escape>', lambda e: self.destroy())

        place_window_center(self)

    def submit(self):
        get_krb5_keys(self.entry_krb.get())
        if not check_krb5_keys():
            logger.info(messages.krb_err_text)
            messagebox.showerror(title=messages.krb_err_title,
                message=messages.krb_err_text,
                icon='info')
        self.destroy()

if __name__ == '__main__':
    app = SetFACL()
    app.run()