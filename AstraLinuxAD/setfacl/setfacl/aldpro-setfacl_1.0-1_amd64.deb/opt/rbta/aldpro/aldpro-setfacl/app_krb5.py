"""
    Модуль для работы с билетами Kerberos
"""

import os
import subprocess

import app_messages as messages
import app_logging

logger = app_logging.logger

def check_krb5_keys():
    """ Функция проверяет наличии TGT-билета в связке ключей """

    try:
        result = subprocess.run(f'klist', capture_output=True, text=True, shell=True)
        if result.returncode == 0:
            logger.info(messages.krb_tgt_key_exists)
            return True
        else:
            logger.info(messages.krb_tgt_key_not_exists)            
            return False

    except subprocess.CalledProcessError:
        return False

def get_krb5_keys(krb5_pwd: str):
    """ Функция запрашивает TGT-билет с помощью утилиты kinit """

    result = subprocess.run(['kinit', os.getlogin()], input=krb5_pwd, text=True)

    if result.returncode == 0:
        logger.info(messages.krb_success)
        return True
    else:
        logger.error(messages.krb_err_text)
        return False
