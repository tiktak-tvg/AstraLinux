"""
    Модуль для логирования в файл, поток вывода и строку состояния
"""

import logging
from systemd.journal import JournalHandler

import app_messages as messages

class AppLogger():
    """ Класс для работы с модулем логирования """

    app = None

    def __init__(self):
        """ Конструктор для инициализации модуля """

        self.log_file_name = f"{messages.app_name}.log"
        self.log_format = f"%(asctime)s - %(levelname)s - %(name)s - %(funcName)s - %(message)s"

        self.logger = logging.getLogger(messages.app_name)
        self.logger.setLevel(logging.INFO)
        self.logger.addHandler(self.get_stream_handler())
        self.logger.addHandler(JournalHandler())

    def get_stream_handler(self):
        """ Обработчик для логирования событий в поток ввода/вывода """

        stream_handler = logging.StreamHandler()
        stream_handler.setLevel(logging.INFO)
        stream_handler.setFormatter(logging.Formatter(self.log_format))
        return stream_handler

# В Python каждый модуль загружается только один раз, поэтому мы можем использовать переменную модуля как Singleton.
logger = AppLogger().logger
