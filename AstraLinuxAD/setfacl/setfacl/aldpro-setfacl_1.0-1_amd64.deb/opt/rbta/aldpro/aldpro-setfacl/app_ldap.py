"""
    Модуль работы с каталогом LDAP.

    Реализует поиск заданного типа объектов (пользователи/группы) в каталоге LDAP и
    возврат в формате json необходимых для добавления ACL атрибутов (uid,cn,uidNumber,gidNumber)
"""
import os
import subprocess
import configparser
import ldap
import ldap.sasl
from tkinter import messagebox

import app_messages as messages
import app_logging

logger = app_logging.logger

def check_file(kdcinfo_path):
    if not os.path.exists(kdcinfo_path):
        raise FileNotFoundError(messages.ldap_error_kdcinfo_file_not_found.replace("%FILENAME%", kdcinfo_path))

    if not os.path.isfile(kdcinfo_path):
        raise FileNotFoundError(messages.ldap_error_kdcinfo_is_not_file.replace("%FILENAME%", kdcinfo_path))

    if not os.access(kdcinfo_path, os.R_OK):
        raise PermissionError(messages.ldap_error_kdcinfo_is_not_readable.replace("%FILENAME%", kdcinfo_path))

def ip_to_fqdn(line):
    line = line.strip()
    if line.count('.') == 3:
        try:
            result = subprocess.run(['host', line], capture_output=True, text=True)
            if result.returncode == 0:
                dc_name = result.stdout.split()[-1]
                return dc_name.strip('.')
        except Exception as e:
            logger.info(messages.ldap_error_ip_to_fqdn.replace("%IP%", line).replace("%ERROR%", e))

    return None

def get_domain():
    ipa_config_file = "/etc/ipa/default.conf"
    try:
        check_file(ipa_config_file)
        ipaconfig = configparser.ConfigParser()
        ipaconfig.read(ipa_config_file)
        return ipaconfig.get("global", "domain")
    
    except (FileNotFoundError, PermissionError) as e:
        logger.error(f"Ошибка: {e}")
        messagebox.showerror(title=messages.app_error_title, 
                message=e,
                icon='error')
        return None

def get_active_connection(domain):
    """ Функция возвращает соединение с активным контроллером домена """

    kdcinfo_path = f"/var/lib/sss/pubconf/kdcinfo.{domain.upper()}"

    try:
        check_file(kdcinfo_path)

        with open(kdcinfo_path, 'r') as file:
            controllers = file.readlines()
    
    except (FileNotFoundError, PermissionError) as e:
        logger.error(f"Ошибка: {e}")
        messagebox.showerror(title=messages.app_error_title, 
                message=e,
                icon='error')
        return None
    
    for _, controller in enumerate(controllers):
        controller_fqdn = ip_to_fqdn(controller)
        ldap_server = f'ldaps://{controller_fqdn}'
        
        conn = ldap.initialize(ldap_server)
        conn.set_option(ldap.OPT_REFERRALS, 0)
        conn.sasl_interactive_bind_s("", ldap.sasl.gssapi())

        return conn

    return None


def ldap_search_subjects(search_string: str, is_user: bool):
    """ Функция выполняет поиск в LDAP-каталоге по заданному критерию """

    domain = get_domain()
    if domain == None:
        return None
    
    conn = get_active_connection(domain)
    if conn == None:
        return None

    domain_components = ("." + domain).replace(".", ",dc=")

    if search_string == messages.search_placeholder:
        search_string = '*'
    else:
        search_string = f'*{search_string}*'

    if is_user:
        search_base = "cn=users,cn=accounts" + domain_components
        search_filter = f'(&(objectclass=posixaccount)(uid={search_string}))'
        retrieve_attrs=["uid", "uidNumber"]
    else:
        search_base = "cn=groups,cn=accounts" + domain_components
        search_filter = f'(&(objectclass=posixgroup)(objectclass=ipausergroup)(cn={search_string}))'
        retrieve_attrs=["cn", "gidNumber"]    

    search_result = []
    search_scope = ldap.SCOPE_ONELEVEL

    try:

        result = conn.search_s(search_base, search_scope, search_filter, retrieve_attrs)
        
        for _, entry in result:
            for key in entry:
                entry[key] = entry[key][0].decode('utf-8')

            search_result.append(entry)

        logger.info(messages.ldap_search_success)
    
    except Exception as e:
        search_result = None
        logger.error(e)
        messagebox.showerror(title=messages.app_warning_title,
            message=e,
            icon='warning')

    finally:
        conn.unbind()
    
    return search_result