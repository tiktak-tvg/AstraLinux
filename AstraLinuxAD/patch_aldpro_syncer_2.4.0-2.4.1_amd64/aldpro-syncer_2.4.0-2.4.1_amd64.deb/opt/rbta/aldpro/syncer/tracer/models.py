from django.db import models


class ModelTracerObjectClass(models.Model):
    name = models.CharField(max_length=255, unique=True, verbose_name='name')
    key = models.CharField(max_length=255, blank=True, default=None,
                           unique=True, null=True, verbose_name='key')
    objects = models.Manager()

    class Meta:
        db_table = 'schema_tracer\".\"tracer_objects'
        verbose_name = 'Класс'
        verbose_name_plural = 'Класс'

    def __str__(self):
        return str(self.name)


class ModelTracerAttributesALDPro(models.Model):
    name = models.CharField(max_length=255, verbose_name='name', unique=True)
    key = models.CharField(
        max_length=255,
        default=None,
        unique=True,
        verbose_name='key'
    )
    lock = models.BooleanField(default=True, verbose_name='lock')

    class Meta:
        db_table = 'schema_tracer\".\"tracer_attribute_aldpro'
        verbose_name = 'Атрибуты полей ALDPro'
        verbose_name_plural = 'Атрибуты полей ALDPro'

    def __str__(self):
        return str(self.name)


class ModelTracerAttributesAD(models.Model):
    name = models.CharField(max_length=255, unique=True, verbose_name='name')
    key = models.CharField(
        max_length=255,
        default=None,
        null=True,
        unique=True,
        verbose_name='key'
    )
    lock = models.BooleanField(default=True, verbose_name='lock')

    class Meta:
        db_table = 'schema_tracer\".\"tracer_attribute_ad'
        verbose_name = 'Атрибуты полей AD'
        verbose_name_plural = 'Атрибуты полей AD'

    def __str__(self):
        return str(self.name)


#
class ModelTracer(models.Model):
    object_class = models.ForeignKey(ModelTracerObjectClass,
                                     on_delete=models.CASCADE, default=None,
                                     verbose_name='object_class')
    key_ald = models.ForeignKey(ModelTracerAttributesALDPro,
                                on_delete=models.CASCADE, default=None,
                                verbose_name='key_ald')
    key_ad = models.ForeignKey(ModelTracerAttributesAD,
                               on_delete=models.CASCADE, default=None,
                               verbose_name='key_ad')
    lock = models.BooleanField(default=True, verbose_name='lock')

    class Meta:
        db_table = 'schema_tracer\".\"tracer'
        verbose_name = 'Tracer атрибутов'
        verbose_name_plural = 'Tracer атрибутов'
        unique_together = (
            ('object_class', 'key_ad'),
            ('object_class', 'key_ald'),
        )
