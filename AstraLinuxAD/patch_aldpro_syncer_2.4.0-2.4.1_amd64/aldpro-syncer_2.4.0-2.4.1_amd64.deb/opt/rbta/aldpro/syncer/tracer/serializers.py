from rest_framework import serializers
from .models import *


class SerializerTracerObjectClass(serializers.ModelSerializer):
    class Meta:
        model = ModelTracerObjectClass
        fields = '__all__'


class SerializerTracerAttributesAD(serializers.ModelSerializer):
    def validate(self, data):
        if ' ' in data['name'] or ' ' in data['key']:
            raise serializers.ValidationError(
                detail='Пробел не может использоваться')
        return data

    class Meta:
        model = ModelTracerAttributesAD
        fields = '__all__'
        extra_kwargs = {'lock': {'default': False}}


class SerializerTracerAttributesALDPro(serializers.ModelSerializer):

    def validate_key(self, value):
        if isinstance(value, str):
            return value.lower()
        else:
            return value

    def validate(self, data):
        if ' ' in data['name'] or ' ' in data['key']:
            raise serializers.ValidationError(detail='Пробел не может использоваться')
        return data
    
    class Meta:
        model = ModelTracerAttributesALDPro
        fields = '__all__'
        extra_kwargs = {'lock': {'default': False}}


class SerializerTracer(serializers.ModelSerializer):

    class Meta:
        model = ModelTracer
        fields = '__all__'
        extra_kwargs = {'lock': {'default': False}}


class SerializerTracerNames(serializers.ModelSerializer):
    object_class = serializers.SlugRelatedField(
            read_only=True,
            slug_field='name'
         )
    key_ad = serializers.SlugRelatedField(
        read_only=True,
        slug_field='name'
    )
    key_ald = serializers.SlugRelatedField(
        read_only=True,
        slug_field='name'
    )

    class Meta:
        model = ModelTracer
        fields = '__all__'


class SerializerTracerString(serializers.ModelSerializer):
    object_class_key = serializers.ReadOnlyField(source='object_class.key')
    object_class_name = serializers.ReadOnlyField(source='object_class.name')
    key_ad_name = serializers.ReadOnlyField(source='key_ad.name')
    key_ald_name = serializers.ReadOnlyField(source='key_ald.name')

    class Meta:
        model = ModelTracer
        fields = '__all__'

