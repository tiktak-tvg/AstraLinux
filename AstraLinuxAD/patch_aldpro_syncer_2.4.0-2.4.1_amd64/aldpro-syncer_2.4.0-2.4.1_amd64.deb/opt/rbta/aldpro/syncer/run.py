import os

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "syncer.settings")

from django.db.utils import OperationalError
import logging
import django

logger = logging.getLogger(__name__)
logger_handler = logging.StreamHandler()
logger_formatter = logging.Formatter('syncer %(levelname)s     %(module)s   %(message)s')
logger_handler.setFormatter(logger_formatter)
logger.addHandler(logger_handler)

try:
    django.setup()
except OperationalError as e:
    logger.critical("Нет подключения к базе данных")
    exit(0)


from services.watcher.watcher import watcher
from services.loadrunner.ipa_load_runner import loadrunner
from services.ipa.api.Api import IPAUnauthorizedException
from services.loadrunner.exceptions import AddMemberException


try:
    watcher(revers=False)
    loadrunner()
    watcher(revers=True)
    loadrunner()
except AddMemberException as e:
    logger.error(e)
except IPAUnauthorizedException as e:
    logger.error(e)
except Exception as e:
    logger.error(e)

