from typing import Dict

from django.core.management.base import BaseCommand
from django.core.paginator import Paginator
from django.db.models import Q

from provider.models import ModelVirtualTreeLDAP

import logging

logger = logging.getLogger("options")


class Command(BaseCommand):
    group_filter = (
        Q(slave_i_d__isnull=False)
        & Q(object_class__key="group")
    )

    def handle(self, *args, **options):
        all_users = {user["slave_i_d"]: user["master_i_d"] for user in self.__fetch_all_objects("user")}
        all_groups = {group["slave_i_d"]: group["master_i_d"] for group in self.__fetch_all_objects("group")}
        units = ModelVirtualTreeLDAP.objects.filter(self.group_filter).order_by("master_i_d")
        paginator = Paginator(units, 10_000)
        for page_num in paginator.page_range:
            update_queue = []
            page = paginator.page(page_num)
            for unit in page.object_list:
                update_queue.append(self.__prepare_update_queue(all_users, all_groups, unit))
            logger.info(f"Выполняю обновление членства групп {unit.object_name} master_id {unit.master_i_d}")
            ModelVirtualTreeLDAP.objects.bulk_update(update_queue, ["master_attributes"], batch_size=10_000)

    def __fetch_all_objects(self, object_class: str) -> Dict[str, str]:
        return ModelVirtualTreeLDAP.objects.filter(slave_i_d__isnull=False, object_class__key=object_class).values(
            "slave_i_d", "master_i_d"
        )

    def __prepare_update_queue(
        self, all_users: Dict[str, str], all_groups: Dict[str, str], unit: ModelVirtualTreeLDAP
    ) -> ModelVirtualTreeLDAP:
        logger.info(f"Обрабатываю группу {unit.object_name} master_id {unit.master_i_d}")
        members = unit.master_attributes["member"]
        if members.get("user"):
            logger.info(f"Обрабатываю пользователей в группе {unit.object_name} master_id {unit.master_i_d}")
            users = [all_users.get(user, user) for user in members.get("user")]
            unit.master_attributes["member"]["user"] = users
        if members.get("group"):
            logger.info(f"Обрабатываю группы в группе {unit.object_name} master_id {unit.master_i_d}")
            group = [all_groups.get(group, group) for group in members.get("group")]
            unit.master_attributes["member"]["group"] = group
        return unit
