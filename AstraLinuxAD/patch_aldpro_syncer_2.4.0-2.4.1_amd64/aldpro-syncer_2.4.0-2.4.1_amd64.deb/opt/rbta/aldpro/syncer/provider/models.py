from django.db import models
from options.models import ModelOptionsAuth
from tracer.models import ModelTracerObjectClass


class ModelProviderStatus(models.Model):
    status = models.TextField(blank=True, verbose_name='status')

    class Meta:
        db_table = 'schema_provider\".\"status'


class ModelGlobalTimeDeleted(models.Model):
    time_last_deleted = models.DateTimeField(null=True, blank=True, default=None, verbose_name='time_last_deleted')
    source_data_deleted = models.ForeignKey(ModelOptionsAuth, on_delete=models.CASCADE, default=None,
                                            verbose_name='source_data_deleted', related_name='source_data_deleted')

    class Meta:
        db_table = 'schema_provider\".\"global_time_deleted'


class ModelIPACodeError(models.Model):
    error_code = models.TextField(blank=True, verbose_name='error_code')
    error_message = models.TextField(blank=True, verbose_name='error_message')
    error_name = models.TextField(blank=True, verbose_name='object_error_nameclass')

    class Meta:
        db_table = 'schema_provider\".\"ipa_code_error'

    def __str__(self):
        return f"{self.error_code}"


class ModelProviderTxRx(models.Model):
    dn_tx = models.TextField(verbose_name='dn_tx')
    options_tx = models.ForeignKey(ModelOptionsAuth, on_delete=models.CASCADE, default=None,
                                   verbose_name='type_tx', related_name='options_tx_sync')
    dn_rx = models.TextField(verbose_name='dn_rx')
    options_rx = models.ForeignKey(ModelOptionsAuth, on_delete=models.CASCADE, default=None,
                                   verbose_name='type_rx', related_name='options_rx_sync')
    time_create = models.DateTimeField(null=True, auto_now_add=True, verbose_name='time create')
    time_updated = models.DateTimeField(null=True, auto_now=True, verbose_name='time updated')
    time_changed = models.DateTimeField(null=True, blank=True, default=None, verbose_name='time_changed')
    is_reversed = models.BooleanField(null=False, verbose_name='is_reversed', default=False)

    class Meta:
        db_table = 'schema_provider\".\"tx_rx'
        unique_together = [['dn_rx', 'options_tx', 'options_rx'],
                           ['dn_tx', 'options_tx', 'options_rx']]


class ModelVirtualTreeLDAP(models.Model):
    structure_i_d = models.ForeignKey(ModelProviderTxRx, on_delete=models.CASCADE, default=None,
                                      verbose_name='object_class')
    master_i_d = models.TextField(null=True, blank=True, default=None, verbose_name='master_i_d')
    slave_i_d = models.TextField(null=True, blank=True, default=None, verbose_name='slave_i_d')
    parent_i_d = models.TextField(null=True, blank=True, default=None, verbose_name='parent_i_d')
    dn = models.TextField(null=True, blank=True, default=None, verbose_name='dn')
    dn_new = models.TextField(null=True, blank=True, default=None, verbose_name='dn_new')
    object_level = models.IntegerField(null=True, blank=True, default=None, verbose_name='object_level')
    object_class = models.ForeignKey(ModelTracerObjectClass, on_delete=models.CASCADE, default=None,
                                     verbose_name='object_class')
    object_name = models.TextField(null=True, blank=True, default=None, verbose_name='object_name')
    object_name_new = models.TextField(null=True, blank=True, default=None, verbose_name='object_name_new')
    time_create = models.DateTimeField(auto_now_add=True, verbose_name='time create')
    time_updated = models.DateTimeField(auto_now=True, verbose_name='time updated')
    master_created = models.DateTimeField(null=True, blank=True, default=None, verbose_name='master_created')
    master_changed = models.DateTimeField(null=True, blank=True, default=None, verbose_name='master_changed')
    slave_created = models.DateTimeField(null=True, blank=True, default=None, verbose_name='slave_created')
    slave_changed = models.DateTimeField(null=True, blank=True, default=None, verbose_name='slave_changed')
    master_attributes = models.JSONField(null=True, blank=True, default=None, verbose_name='master_attributes')
    slave_attributes = models.JSONField(null=True, blank=True, default=None, verbose_name='slave_attributes')
    status = models.ForeignKey(ModelProviderStatus, on_delete=models.CASCADE, default=None,
                               verbose_name='status')
    execute = models.BooleanField(default=False, verbose_name='execute')
    parent = models.TextField(null=True, blank=True, default=None, verbose_name='parent')
    parent_new = models.TextField(null=True, blank=True, default=None, verbose_name='parent_new')
    blockpwd = models.BooleanField(default=False, verbose_name='blockpwd')
    error = models.ForeignKey(
        ModelIPACodeError,
        on_delete=models.SET_NULL,
        null=True, verbose_name='error'
    )

    class Meta:
        db_table = 'schema_provider\".\"virtual_tree'


