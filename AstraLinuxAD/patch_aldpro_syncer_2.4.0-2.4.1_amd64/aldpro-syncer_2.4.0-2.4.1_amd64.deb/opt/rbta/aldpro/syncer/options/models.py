from django.db import models


class ModelOptionsProviderType(models.Model):
    type = models.TextField(blank=True,
                            verbose_name='type',
                            unique=True)

    class Meta:
        db_table = 'schema_options\".\"type'


class ModelOptionsKey(models.Model):
    public_key = models.TextField(blank=True, verbose_name='public key')
    private_key = models.TextField(blank=True, verbose_name='private key')
    kvno = models.AutoField(primary_key=True, verbose_name='kvno')

    class Meta:
        db_table = 'schema_options\".\"key'

    def __str__(self):
        return f'{self.pk}'


class ModelOptionsAuth(models.Model):
    type = models.ForeignKey(ModelOptionsProviderType,
                             on_delete=models.CASCADE,
                             default=None,
                             verbose_name='type')
    host = models.TextField(blank=True,
                            verbose_name='host',
                            default=None,
                            unique=True)
    user = models.TextField(blank=True,
                            verbose_name='user',
                            default=None)
    password = models.TextField(blank=True,
                                verbose_name='password',
                                default=None)
    time_updated = models.DateTimeField(auto_now=True,
                                        verbose_name='time updated')
    key = models.TextField(blank=True,
                           verbose_name='tls key file',
                           default=None,
                           null=True)

    class Meta:
        db_table = 'schema_options\".\"auth'


class ModelDCReplica(models.Model):
    host_name = models.CharField(unique=True, null=False, max_length=253)
    auth = models.ForeignKey(
        ModelOptionsAuth,
        null=True,
        on_delete=models.SET_NULL,
        related_name='replica'
    )

    class Meta:
        db_table = 'schema_options\".\"replica'

    def __str__(self):
        return f'{self.host_name}'
