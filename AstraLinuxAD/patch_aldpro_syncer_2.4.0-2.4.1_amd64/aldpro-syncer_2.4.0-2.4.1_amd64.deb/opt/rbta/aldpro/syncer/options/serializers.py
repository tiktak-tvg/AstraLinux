from rest_framework import serializers

from .models import *
from services.options.pass_encryption.passencrypt import *


class SerializerOptions(serializers.ModelSerializer):
    type_name = serializers.ReadOnlyField(source='type.type')

    class Meta:
        model = ModelOptionsAuth
        fields = '__all__'


class SerializerBindOptions(serializers.ModelSerializer):
    type = serializers.ReadOnlyField(source='type.type')
    replica = serializers.SerializerMethodField()

    class Meta:
        model = ModelOptionsAuth
        fields = "__all__"

    def get_replica(self, obj):
        return [host.host_name.lower() for host in obj.replica.all()]


class SerializerOptionsProviderType(serializers.ModelSerializer):
    class Meta:
        model = ModelOptionsProviderType
        fields = '__all__'


class SerializerOptionsKey(serializers.ModelSerializer):
    class Meta:
        model = ModelOptionsKey
        fields = ['kvno', 'public_key']
        extra_kwargs = {
            'public_key': {'read_only': True, 'required': False}
        }

    def validate(self, attrs):
        pass_encryption = PassEncryption()
        encryption_keys = pass_encryption.get_keys()
        attrs['public_key'] = encryption_keys['public_key']
        attrs['private_key'] = encryption_keys['private_key']
        return attrs
