import sys
from pathlib import Path
import os
from decouple import config
import logging
import yaml

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# Get vars from .env file to config variable

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = config('SECRET_KEY')

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = config('DEBUG', default=False, cast=bool)

ALLOWED_HOSTS = config(
    'ALLOWED_HOSTS', default=['*'], cast=lambda v: [s.strip() for s in v.split(',')]
)

SUBSTITUTION_RULES = []


custom_rule_path = BASE_DIR.joinpath('services/utils/custom_rule.yaml')
base_rule_path = BASE_DIR.joinpath('services/utils/base_rule.yaml')

if custom_rule_path.exists():
    with open(custom_rule_path) as file:
        try:
            SUBSTITUTION_RULES.append(yaml.safe_load(file))
        except yaml.scanner.ScannerError:
            logging.warning(f"Файл {custom_rule_path} пользовательских настроек не является валидным")

with open(base_rule_path) as file:
    try:
        SUBSTITUTION_RULES.append(yaml.safe_load(file))
    except yaml.scanner.ScannerError:
        logging.error(f"Файл {base_rule_path} базовых настроек не является валидным")
        exit(1)

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'basic': {
            '()': 'colorlog.ColoredFormatter',
            'format': '%(log_color)s%(asctime)-8s syncer %(levelname)s     %(module)s   %(message)s',
            'datefmt': '%Y-%m-%d %H:%M:%S',
            'log_colors': {
                'DEBUG': 'blue',
                'INFO': 'white',
                'WARNING': 'yellow',
                'ERROR': 'red',
                'CRITICAL': 'bold_red',
            },
        },
        'file_format': {
            'format': '{asctime} syncer {levelname}  {module}  {message}',
            'style': '{',
            'datefmt': '%Y-%m-%d %H:%M:%S',
        }
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'basic',
            'level': 'DEBUG',
        },
        'file': {
            'class': 'logging.FileHandler',
            'filename': f'{BASE_DIR}/info.log',
            'formatter': 'file_format'
        },
    },
    'django.db.backends': {
        'level': 'DEBUG',
        'handlers': ['console'],
        'propagate': False,
    },
    'loggers': {
        'options': {
            'handlers': ['console', ] if DEBUG else ['file', ],
            'level': 'DEBUG' if DEBUG else 'INFO',
            'propagate': False,
        },
        'tracer': {
            'handlers': ['console', ] if DEBUG else ['file', ],
            'level': 'DEBUG' if DEBUG else 'INFO',
            'propagate': False,
        },
        'services': {
            'handlers': ['console', ] if DEBUG else ['file', ],
            'level': 'DEBUG' if DEBUG else 'INFO',
            'propagate': False,
        },      
        'services.options': {
            'handlers': ['console', ] if DEBUG else ['file', ],
            'level': 'DEBUG' if DEBUG else 'INFO',
            'propagate': False,
        },
        'services.utils': {
            'handlers': ['console', ] if DEBUG else ['file', ],
            'level': 'DEBUG' if DEBUG else 'INFO',
            'propagate': False,
        },
        'services.tracer': {
            'handlers': ['console', ] if DEBUG else ['file', ],
            'level': 'DEBUG' if DEBUG else 'INFO',
            'propagate': False,
        },
    },
}

# Application definition

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django_extensions',

    # third
    'rest_framework',
    'corsheaders',
    'django_filters',
    # 'silk',

    # app
    'tracer',
    'provider',
    'options',
]

MIDDLEWARE = [
    # 'silk.middleware.SilkyMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'syncer.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates']
        ,
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'syncer.wsgi.application'

# Database
# https://docs.djangoproject.com/en/4.1/ref/settings/#databases

DB_NAME = config('SYNCER_DB_NAME', default='')
DB_USER = config('SYNCER_DB_USER', default='')
DB_PASSWORD = config('SYNCER_DB_PASSWORD', default='')
DB_HOST = config('SYNCER_DB_HOST', default='localhost')
DB_PORT = config('SYNCER_DB_PORT', default=5432, cast=int)

if len(sys.argv) > 1 and sys.argv[1] == 'test':
    db_options = '-c search_path=public,django'
else:
    db_options = '-c search_path=schema_django'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'OPTIONS': {
            'options': f'{db_options}'
        },
        'NAME': DB_NAME,
        'USER': DB_USER,
        'PASSWORD': DB_PASSWORD,
        'HOST': DB_HOST,
        'PORT': DB_PORT,
    }
}

CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
    }
}

# Password validation
# https://docs.djangoproject.com/en/4.1/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Internationalization
# https://docs.djangoproject.com/en/4.1/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_TZ = True

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/4.1/howto/static-files/

if DEBUG:
    STATICFILES_DIRS = [os.path.join(BASE_DIR, 'staticfiles')]
else:
    STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')
STATIC_URL = '/static/'

# Default primary key field type
# https://docs.djangoproject.com/en/4.1/ref/settings/#default-auto-field

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

CORS_ORIGIN_ALLOW_ALL = True
CORS_ALLOW_CREDENTIALS = True
CORS_ALLOW_METHODS = [
    'DELETE',
    'GET',
    'OPTIONS',
    'PATCH',
    'POST',
    'PUT',
]

PROVIDER_TLS_KEY_DIR = '/var/run/syncer/provider/'
os.makedirs(PROVIDER_TLS_KEY_DIR, exist_ok=True)


# Disable logging when tests use
if len(sys.argv) > 1 and sys.argv[1] == 'test':
    logging.disable(logging.CRITICAL)
