import typing as _T

class PostgreSQLConnectionError(Exception):
    code: int = 500
    title: str
    detail: _T.Any
    fromModule: str

    def __init__(self, title: str, detail: _T.Any = None, fromModule: _T.Optional[str] = None, code = code):
        self.title = title
        self.detail = detail
        self.fromModule = fromModule or 'syncer'
        self.code = code

class LDAPConnectionError(Exception):
    code: int = 500
    title: str
    detail: _T.Any
    fromModule: str

    def __init__(self, title: str, detail: _T.Any = None, fromModule: _T.Optional[str] = None, code = code):
        self.title = title
        self.detail = detail
        self.fromModule = fromModule or 'syncer'
        self.code = code