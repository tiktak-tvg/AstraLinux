import django

django.setup()

from django.db.models import QuerySet
from provider.models import ModelVirtualTreeLDAP, ModelProviderStatus, ModelIPACodeError
from services.loadrunner.serializers import LoadRunnerSerializers, SerializerVirtualTreeLDAP, IPAException
from services.provider.provider import Provider
from services.options.options import get_auth_options
from services.ipa.api.Api import IPAUnauthorizedException
from services.provider.exception import NotConnectedToProvider
from services.loadrunner.exceptions import AddMemberException, SlaveIdNotExist
import copy
from services.provider.strategy import ProviderStrategiesDict
import logging

logger = logging.getLogger(__name__)

STATUS_CREATED = 'created'
STATUS_UPDATED = 'updated'
STATUS_DELETED = 'deleted'


def runner_objects_by_status(object_classes: list, status: str, reverse: bool, order_by: tuple = ("id", )):
    logger.info(f"Запуск loadrunner для {status}")
    for object_class in object_classes:
        units_run = get_objects(
            object_class=object_class,
            status=status,
            order_by=order_by
        )

        if units_run:
            for unit in units_run:
                runner_objects(unit=unit, status=status, reverse=reverse)


def loadrunner(reverse: bool = False):
    logger.info(f"Запуск loadrunner")
    object_classes = ['user', 'group', 'organizationalUnit']
    logger.debug('-=Удаление объектов=-')
    runner_objects_by_status(
        object_classes=object_classes,
        status=STATUS_DELETED,
        reverse=reverse,
        order_by=('id', )
    )

    logger.debug('-=Создание объектов=-')
    object_classes = ['organizationalUnit', 'user', 'group']
    runner_objects_by_status(
        object_classes=object_classes,
        status=STATUS_CREATED,
        reverse=reverse,
        order_by=("master_created", "id")
    )

    logger.debug('-=Обновление объектов=-')
    object_classes = ['organizationalUnit', 'user', 'group']
    runner_objects_by_status(
        object_classes=object_classes,
        status=STATUS_UPDATED,
        reverse=reverse,
        order_by=("master_changed", "id")
    )
    logger.info(f"loadrunner завершился")
    return


def get_objects(object_class: str, status: str, order_by: tuple = ("master_created", )) -> QuerySet:
    units = ModelVirtualTreeLDAP.objects.select_related(
        'structure_i_d', 'structure_i_d__options_rx', 'structure_i_d__options_rx__type'
    ).prefetch_related(
        'structure_i_d__options_rx__replica'
    ).filter(
        execute=True,
        status__status=status,
        object_class__key=object_class
    ).order_by(*order_by)
    return units


def remove_password_attr(unit: ModelVirtualTreeLDAP, runner, blockpwd: bool = True):
    if unit.object_class.key == 'user':
        if unit.structure_i_d.is_reversed:
            unit.slave_attributes.get("attributes", {}).pop(runner.passwd_field_name(), None)
        else:
            unit.master_attributes.get("attributes", {}).pop(runner.passwd_field_name(), None)
        unit.save()


def set_blokpwd(unit: ModelVirtualTreeLDAP, runner, blockpwd: bool = True):
    if unit.object_class.key == 'user':
        unit.blockpwd = blockpwd
        unit.save()
    logger.debug(f"Blocking user for watcher: {unit.blockpwd}")
    return unit.blockpwd


def runner_objects(unit, status, reverse: bool):

    if reverse:
        options = get_auth_options(unit.structure_i_d.options_tx)
    else:
        options = get_auth_options(unit.structure_i_d.options_rx)
    if options['type'] == "AD":
        provider = Provider(ProviderStrategiesDict[options['type']]['LDAP']())
    else:
        provider = Provider(ProviderStrategiesDict[options['type']]['API']())

    try:
        provider.bind(options_bind=options)
    except NotConnectedToProvider:
        raise IPAUnauthorizedException


    try:
        instance = SerializerVirtualTreeLDAP(instance=unit)
        runner = LoadRunnerSerializers[options['type']].get(unit.object_class.key)(
            data=copy.deepcopy(instance.data),
            connection=provider
        )
        logger.info(f"Синхронизация объекта (id={unit.id}, name={unit.object_name}), slave_i_d={unit.slave_i_d}")

        if status == STATUS_CREATED:
            runner.is_valid(raise_exception=True)
            res = runner.create()
            slave_i_d = res.json().get('result', {}).get('result', {}).get('nsuniqueid', None)
            if slave_i_d:
                unit.slave_i_d = slave_i_d[0]
            logger.debug(f"slave_i_d объекта = {unit.slave_i_d}")
            unit.execute = True
            unit.status = ModelProviderStatus.objects.get(status=STATUS_UPDATED)
            set_blokpwd(unit=unit, runner=runner)
            remove_password_attr(unit=unit, runner=runner)
        elif status == STATUS_UPDATED:
            if not instance.data.get('slave_i_d'):
                raise SlaveIdNotExist(f"Объект с id={unit.pk} не имеет slave_i_d")
            runner.is_valid(raise_exception=True)
            res = runner.update()
            unit = ModelVirtualTreeLDAP.objects.get(master_i_d=unit.master_i_d)
            set_blokpwd(unit=unit, runner=runner)
            remove_password_attr(unit=unit, runner=runner)
            unit.execute = False
            unit.parent = unit.parent_new
            unit.object_name = unit.object_name_new
        elif status == STATUS_DELETED:
            if not instance.data.get('slave_i_d'):
                raise SlaveIdNotExist(f"Объект с id={unit.pk} не имеет slave_i_d")
            runner.is_valid(raise_exception=True)
            res = runner.delete()
            unit.execute = False
    except IPAUnauthorizedException:
        raise
    except AddMemberException as e:
        logger.warning(e)
        return
    except Exception as e:
        try:
            error_code = e.error_code
            unit.error = ModelIPACodeError.objects.get(error_code=error_code)
        except:
            unit.error = ModelIPACodeError.objects.get(error_code=-1)
            logger.exception("Неизвестная ошибка")
        logger.error(e)
        if hasattr(e, "debug"):
            logger.debug(e.debug)
        unit.execute = False
    else:
        unit.error = None
        if hasattr(res, "json"):
            logger.info(res.json())
        else:
            logger.info(res)
    finally:
        unit.save()
        provider.unbind()
