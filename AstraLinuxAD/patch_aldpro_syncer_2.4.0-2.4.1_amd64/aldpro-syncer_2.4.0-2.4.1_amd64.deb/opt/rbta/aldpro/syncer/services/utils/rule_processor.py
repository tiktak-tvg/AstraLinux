import functools
from typing import Dict

from django.conf import settings


def process_substitution(
    substitution: Dict, obj_type: str, attr_type: str, attr_value: str
) -> str:
    """Функция выполняет замену на основе правила замены
       Атрибут/ы из source заменяются на dest

    Args:
        substitution (Dict): Список правил
        obj_type (str): Тип объекта к которому применить правило
        attr_type (str): Тип Атрибута
        attr_value (str): Значение атрибута

    Returns:
        str: Обработанный атрибут
    """
    try:
        attr_rules = substitution[obj_type].get(attr_type)
        replace_value = (
            attr_value.replace("\\t", "\t").replace("\\n", "\n")
        )
        if attr_rules:
            for rule in attr_rules:
                sources = rule["rule"]["source"]
                if isinstance(sources, list):
                    replace_value = functools.reduce(
                        lambda s, r: s.replace(
                            r,
                            rule["rule"]["dest"],
                        ),
                        sources,
                        replace_value,
                    )
                else:
                    replace_value = replace_value.replace(sources, rule["rule"]["dest"])
        return replace_value
    except KeyError:
        return attr_value


def process_replace(obj_type: str, attr_type: str, attr_value: str) -> str:
    """Выполнить перенаправление в зависимости от типа правила

    Args:
        obj_type (str): Тип объекта к которому применить правило
        attr_type (str): Тип Атрибута
        attr_value (str): Значение атрибута

    Returns:
        str: Обработанный атрибут
    """
    for rule in settings.SUBSTITUTION_RULES:
        custom_substitution = rule.get("customrule", None)
        if custom_substitution:
            version = rule.get("version")
            attr_value = process_substitution(
                custom_substitution, obj_type, attr_type, attr_value
            )
        base_substitution = rule.get("baserule", None)
        if base_substitution:
            version = rule.get("version")
            attr_value = process_substitution(
                base_substitution, obj_type, attr_type, attr_value
            )
    return attr_value
