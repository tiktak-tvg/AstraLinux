from __future__ import annotations

import typing
from typing import List, Dict
from services.provider.strategy import ProviderStrategy
import logging
from functools import wraps

logger = logging.getLogger(__name__)


def print_params(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        logger.debug(f"{func.__name__}: {kwargs}")
        res = func(*args, **kwargs)
        return res

    return wrapper


class Provider:

    def __init__(self, strategy: ProviderStrategy) -> None:
        self._strategy = strategy

    @property
    def strategy(self) -> ProviderStrategy:
        return self._strategy

    @strategy.setter
    def strategy(self, strategy: ProviderStrategy) -> None:
        self._strategy = strategy

    def bind(self, options_bind: Dict) -> None:
        self._strategy.do_bind(options_bind=options_bind)

    def unbind(self) -> None:
        self._strategy.do_unbind()

    def search(self,
               base_ou: str = None,
               filter_ldap: str = None,
               deletion: bool = False,
               search_ald: bool = False) -> List:
        """
        Return list names of hosts domain's replicas
        """
        return self._strategy.do_search(base_ou=base_ou,
                                        filter_ldap=filter_ldap,
                                        deletion=deletion,
                                        search_ald=search_ald)

    def search_with_pagination(self,
                               base_ou: str = None,
                               filter_ldap: str = None,
                               deletion: bool = False,
                               search_ald: bool = False,
                               pagination: bool = False) -> typing.Generator:
        return self._strategy.do_search_with_pagination(base_ou=base_ou,
                                                        filter_ldap=filter_ldap,
                                                        deletion=deletion,
                                                        search_ald=search_ald,
                                                        pagination=pagination)

    def search_base(self, base_ou: str = None, filter_ldap: str = None) -> List:
        """
        Return list names of hosts domain's replicas
        """
        return self._strategy.do_search_base(base_ou=base_ou, filter_ldap=filter_ldap)

    def insert_data(self, *args, **kwargs):
        """
        Insert data to strategy's storage
        """
        return self._strategy.do_insert_data(*args, **kwargs)

    def update_data(self, *args, **kwargs):
        """
        Modify data to strategy's storage
        """
        return self._strategy.do_update_data(*args, **kwargs)

    def get_data(self, *args, **kwargs):
        """
        Get data from strategy's storage
        """
        return self._strategy.do_get_data(*args, **kwargs)

    def get_hosts_dc(self) -> List:
        """
        Return list names of hosts domain's replicas
        """
        return self._strategy.get_hosts_dc()

    def get_org_units_dc(self, base_ou: str = '', deep: bool = True) -> List:
        """
        Return list names of organization units in domain's controller
        """
        return self._strategy.get_org_units(base_ou=base_ou, deep=deep)


