class NotConnectedToProvider(Exception):
    """Исключения при невозможности подключиться к провайдеру"""