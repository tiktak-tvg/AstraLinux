PORT_LDAP = 389
PORT_LDAPS = 636
PORT_FREEIPA = 443
MIN_DATA_LDAP = "20000119054347.0Z"
FLT_OBJECTS = f'(&(|(objectClass=user)(objectClass=group)(objectClass=organizationalUnit))(!(objectClass=computer)))'
DELTA_TIME_CHECKING_IS_CHANGED = 0.1
