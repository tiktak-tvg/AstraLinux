from transliterate import translit


def transliterate_name(value: str):
    value = value.strip().lower()
    value = value.replace("ъ", '..')
    value = value.replace("ь", '.')
    value = value.replace("ю", 'yu')
    value = value.replace("я", 'ya')
    value = value.replace("щ", 'shh')
    value = value.replace("х", 'kh')
    translit_value = translit(value, 'ru', reversed=True)
    translit_value = translit_value.replace("'", '')
    translit_value = translit_value.replace(' ', '_')
    return translit_value
