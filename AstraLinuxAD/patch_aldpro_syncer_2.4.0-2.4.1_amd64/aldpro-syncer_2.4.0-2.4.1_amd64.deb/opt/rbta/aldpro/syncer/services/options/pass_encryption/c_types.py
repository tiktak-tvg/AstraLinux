import ctypes

class KEYS_t(ctypes.Structure):
    _fields_ = [('public_key', ctypes.c_char_p),
                ('private_key', ctypes.c_char_p)]

class union_c(ctypes.Union):
    _fields_ = [('keys', KEYS_t), ('resultData', ctypes.c_char_p)]

class result_st_t(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [('status', ctypes.c_int),
                ('u', union_c),
                ('errMSG', ctypes.c_char_p)]