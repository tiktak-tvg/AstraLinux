class WatcherEPWDException(Exception):
    """Исключение при отсутствии поля epwd для пользователя"""


class ObjectDoesNotExistInDataBase(Exception):
    """Исключение при отсутствии объекта синхронизациии в базе данных"""