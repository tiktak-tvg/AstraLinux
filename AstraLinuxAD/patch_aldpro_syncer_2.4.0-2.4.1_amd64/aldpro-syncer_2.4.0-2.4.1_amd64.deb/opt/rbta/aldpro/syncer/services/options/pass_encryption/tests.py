from .passencrypt import *

json_str = """{"base64_size":344,"cipher_size":256,"enc_base64":"GSmkUeUzzBbKtQC5QLXrtcjJuylEkz1vSHe7ma9h5EruwIybYvxiPhY9aHWT6IQKMX1aXpFToLs6h5/SGfq7Ionm+ENgnIrUGqqLYUKvXpRNCaNnFZTk3FUge3zJIFFiVKmdECR9hpJqgTpF2fuF3JDretfqCbh8PV/IywcnAZxyYRtG/wBLD2j/Q7Av2t/MNI72aHuo966smX+UuIaRSVioszRIHrlzt1WurK+fuxdjbyLfsQRm3XeOaQwPd/nAWLfYb8u1mbJ4E2u2RE6Wm36X+WYyE/pQKJXk/0INckne0t7qwnazbmbPDFnKrsKPYeGGmkfTZolIsrX6lH1mog==","kvnopub":3}"""

#Получение ключей
def get_keys():
    f = PassEncryption()
    res = f.get_keys()
    return res
    
    
def decrypt_password():
    pkey = None
    with open('/tmp/priv.pem', 'rb') as f:
        pkey = f.read()
    print(pkey)
    f = PassEncryption()
    return f.decrypt_password(json_str, pkey)

def get_kvno_version():
    pass



if __name__ == '__main__':
    f = PassEncryption()
    res = f.get_keys()
    # json_parse(json_str) 