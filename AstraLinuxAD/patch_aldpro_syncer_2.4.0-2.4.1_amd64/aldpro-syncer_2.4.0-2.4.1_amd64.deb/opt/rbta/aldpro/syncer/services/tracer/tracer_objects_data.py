import sys
from typing import Dict

from django.core.cache import cache
from django.db.models.signals import post_save
from django.dispatch import receiver

from tracer.models import ModelTracerObjectClass, ModelTracer
from tracer.serializers import SerializerTracerString
import logging

logger = logging.getLogger(__name__)


def get_tracer_object_data():
    if 'makemigrations' not in sys.argv and 'migrate' not in sys.argv and 'test' not in sys.argv:
        object_class_data = {}
        object_class = ModelTracerObjectClass.objects.values('key', 'id')
        for n in object_class:
            object_class_data[n['key']] = n['id']
        cached_data = cache.get('tracer_object')
        if cached_data is None or object_class_data != cached_data:
            logger.debug("Tracer_Object writing in-memory cache")
            logger.debug(object_class_data)
            cache.set('tracer_object', object_class_data, None)
        else:
            logger.debug("Data wasn't changed. Cache not updated.")
    else:
        return


def get_tracer_attribute(object_class_data: Dict):
    if 'makemigrations' not in sys.argv and 'migrate' not in sys.argv and 'test' not in sys.argv:
        attributes = {}
        queryset = ModelTracer.objects.prefetch_related('object_class',
                                                        'key_ald',
                                                        'key_ad').all()
        serializer = SerializerTracerString(queryset, many=True)

        for object_class_key, object_class_value in object_class_data.items():
            key_ad = []
            key_ald = []
            for item in serializer.data:
                if item['object_class_key'] == object_class_key:
                    key_ald.append(item['key_ald_name'])
                    key_ad.append(item['key_ad_name'])
            attributes[object_class_key] = {'key_ald': key_ald,
                                            'key_ad': key_ad}
        cached_data = cache.get('tracer_attributes')
        # Line to check how many queries sending
        if cached_data is None or attributes != cached_data:
            logger.debug("Tracer_Attributes writing in-memory cache")
            logger.debug(attributes)
            cache.set('tracer_attributes', attributes, None)
        else:
            logger.debug("Data wasn't changed. Cache not updated.")
    else:
        return


def get_tracer_object_cached():
    return cache.get('tracer_object')


def get_tracer_attributes_cached():
    return cache.get('tracer_attributes')


@receiver(post_save, sender=ModelTracerObjectClass)
def update_cache_object_class(sender, instance, **kwargs):
    """
    This method updating cache
     when data changed in db
    """
    logger.debug("Updating Cache")
    get_tracer_object_data()


@receiver(post_save, sender=ModelTracer)
def update_cache_attributes(sender, instance, **kwargs):
    """
    This method updating cache
     when data changed in db
    """
    logger.debug("Updating Cache")
    get_tracer_attribute(cache.get('tracer_object'))
