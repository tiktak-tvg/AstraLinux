import json
import requests
import urllib3 

urllib3.disable_warnings(urllib3.exceptions.SecurityWarning)


class IPAUnauthorizedException(Exception):
    ...


class Api:
    def __init__(self, host, username, password,
                 protocol='https', verify_ssl=True, version='2.228', kerberos=False):
        self._kerberos = kerberos
        self._host = host
        self._username = username
        self._password = password
        self._protocol = protocol
        self._verify_ssl = verify_ssl
        self._version = version
        self._baseurl = f'{self._protocol}://{self._host}/ipa'  # ("%s://%s/ipa" % (self._protocol, self._host))
        self._sessionurl = f'{self._baseurl}/session/json'  # "%s/session/json" % self._baseurl
        self._loginurl = f'{self._baseurl}/session/login_password'  # "%s/session/login_password" % self._baseurl
        self._session = requests.Session()
        self._session.url = self._baseurl
        self._session.verify = self._verify_ssl
        self._session.headers = {
            'Referer': self._baseurl,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        self.krb_url = f'{self._baseurl}/session/login_kerberos'
        self.login()

    def login(self):
        loginheaders = {'referer': self._loginurl, 'Content-Type': 'application/x-www-form-urlencoded',
                        'Accept': 'application/json'}
        logindata = {'user': self._username, 'password': self._password}
        response = self.post(self._loginurl, data=logindata, headers=loginheaders)
        return response

    def post(self, *dargs, **kwargs):
        response = self._session.post(*dargs, **kwargs)
        return response

    def request(self, method, args=None, params=None):
        if args:
            if not isinstance(args, list):
                args = [args]
        else:
            args = []
        if not params:
            params = {}
        if self._version:
            params.setdefault('version', self._version)
        data = {'id': 0, 'method': method, 'params': [args, params]}
        response = self.post(self._sessionurl, data=json.dumps(data))
        if response.status_code == 401:
            self.login()
            response = self.post(self._sessionurl, data=json.dumps(data))
            if response.status_code == 401:
                raise IPAUnauthorizedException("Не правильный логин или пароль")
        return response

