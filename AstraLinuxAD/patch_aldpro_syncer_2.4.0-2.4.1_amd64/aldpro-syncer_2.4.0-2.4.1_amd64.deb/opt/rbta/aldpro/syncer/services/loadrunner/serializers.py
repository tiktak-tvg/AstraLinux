import re
import sys
import inspect
import uuid

from rest_framework import serializers
from provider.models import ModelVirtualTreeLDAP
from requests.exceptions import HTTPError
from functools import wraps
from services.ipa.api.ou import UpdateOu
from services.options.pass_encryption.passencrypt import PassEncryption
from services.loadrunner.exceptions import (
    CheckMemberException,
    AddMemberException,
    ClearMembersException,
    ObjectGUIDNotFindException,
    ParentSlaveIdNotExist
)
from datetime import datetime, timedelta
from options.models import ModelOptionsKey
from django.shortcuts import get_object_or_404
from ldap import MOD_REPLACE
import json
import logging

logger = logging.getLogger(__name__)



ERROR_DUBLICATE = 4002
ERROR_MODLIST_EMPTY = 4202

LoadRunnerSerializers = dict()
LoadRunnerSerializers.setdefault('AD', {})
LoadRunnerSerializers.setdefault('ALD', {})


class IPAException(HTTPError):
    def __init__(self, message, error_code, debug=None):
        self.error_code = error_code
        self.message = message
        self.debug = debug if debug else message

    def __str__(self):
        return f"{self.message}"


def create_dict_serializers_classes():
    for name, obj in inspect.getmembers(sys.modules[__name__]):
        if inspect.isclass(obj) and hasattr(obj, 'name_unit'):
            LoadRunnerSerializers[obj.type_unit][obj.name_unit] = obj


def raise_for_error(func):
    allowable_errors = []

    @wraps(func)
    def wrapper(*args, **kwargs):
        res = func(*args, **kwargs)
        error = res.json().get('error', None) and res.json()['error']['code']
        if error and error not in allowable_errors:
            raise IPAException(
                f"{res.json()['error']}",
                error_code=error,
                debug=f"url: {res.url}.\nresponse: {res.json()['error']}"
            )
        return res
    return wrapper


class SerializerVirtualTreeLDAP(serializers.ModelSerializer):
    class Meta:
        model = ModelVirtualTreeLDAP
        fields = '__all__'
        depth = 5


class BaseUnitSerializer(serializers.Serializer):

    GUID_FIELD_NAME = 'objectGUID'
    DISTINGUISHED_FIELD_NAME = 'distinguishedName'

    def __init__(self, *args, **kwargs):
        self._name_string = str()
        connection = kwargs.pop('connection', None)
        super(BaseUnitSerializer, self).__init__(*args, **kwargs)
        self._connection = connection

    def _get_create_params(self) -> dict:
        pass

    def _get_update_params(self) -> dict:
        pass

    def _get_delete_params(self) -> dict:
        pass

    def _pre_create(self):
        pass

    def _pre_update(self):
        pass

    def _pre_delete(self):
        pass

    def _post_create(self):
        pass

    def _post_update(self):
        pass

    def _post_delete(self):
        pass

    def to_representation(self, instance):
        result = dict()
        result.update({'create': self._get_create_params()})
        result.update({'update': self._get_update_params()})
        result.update({'delete': self._get_delete_params()})

        return result

    @raise_for_error
    def create(self):
        self._pre_create()
        self.res = self._connection.insert_data(**self.data['create'])
        error = self.res.json().get('error', None)
        if error:
            if not error.get('code', None) == 4202:
                return self.res
        self._post_create()
        return self.res

    @raise_for_error
    def update(self):
        self._pre_update()
        res = self._connection.update_data(**self.data['update'])
        error = res.json().get('error', None)
        if error:
            if not error.get('code', None) == 4202:
                return res
        self._post_update()
        return res

    @raise_for_error
    def delete(self):
        self._pre_delete()
        res = self._connection.insert_data(**self.data['delete'])
        error = res.json().get('error', None)
        if error:
            if not error.get('code', None) == 4202:
                return res
        self._post_delete()
        return res

    def get_parent_ou(self, parent_ou: str, root_ou: str):
        dn_parent = parent_ou
        dn_parent = ','.join(filter(None, [dn_parent, root_ou]))
        return dn_parent

    def get_dn_by_guid(self, guid: str) -> str:
        """
        Get dn from ldap by GUID
        guid: GUID for search object in LDAP
        return: string dn
        """
        guid_adapt = uuid.UUID(bytes=uuid.UUID(guid).bytes_le).hex
        guid_adapt = '\\'.join(guid_adapt[i:i + 2] for i in range(0, len(guid_adapt), 2))
        guid_adapt = '\\'.join(("", guid_adapt))
        for i in range(3):
            try:
                res = self._connection.search(filter_ldap=f'(|({self.GUID_FIELD_NAME}={guid_adapt}))')
                dn = res[0][1].get(self.DISTINGUISHED_FIELD_NAME, None)[0].decode()
                break
            except AttributeError:
                continue
        else:
            raise ObjectGUIDNotFindException(f"Не удалось найти объект в лдап с {self.GUID_FIELD_NAME}={guid}")

        return dn

    def entry_find(self, method, pk, nsuniqueid, deep=False):
        params = {"nsuniqueid":  nsuniqueid, 'all': True, }
        if deep:
            params.update({'deep': True})
        res = self._connection.get_data(method=method, args=[], params=params)
        attrs = res.json().get('result', {}).get('result', {})[0]
        return attrs.get(pk)[0] if isinstance(attrs.get(pk), list) else attrs.get(pk)

    def get_parent_dn(self, guid, method, pk, root, deep=True):
        parent = ModelVirtualTreeLDAP.objects.filter(master_i_d=guid).first()
        if not parent:
            return None
        elif not parent.slave_i_d:
            raise ParentSlaveIdNotExist("Родительское подразделение не было синхронизировано")
        dn = self.entry_find(method, pk, parent.slave_i_d, deep)
        return dn.replace(f",{root}", '')


class GroupIPASerializer(BaseUnitSerializer):
    name_unit = 'group'
    type_unit = 'ALD'
    user_prefix = 'cn=users,cn=accounts'
    group_prefix = 'cn=groups,cn=accounts'
    service_prefix = 'cn=services,cn=accounts'


    name = serializers.CharField(default="name test")
    rbtadp = serializers.CharField()
    user_member = serializers.ListField(child=serializers.CharField())
    group_member = serializers.ListField(child=serializers.CharField())
    service_member = serializers.ListField(child=serializers.CharField())
    rename = serializers.CharField(allow_null=True)
    attributes = serializers.JSONField()
    slave_i_d = serializers.CharField(allow_null=True, allow_blank=True)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._members = dict()
        self._members['user'] = list()
        self._members['group'] = list()
        self._members['service'] = list()

    @raise_for_error
    def get_group_info(self, group_name: str):
        """Возвращает иноформацию о группе
        args:
            group_name: имя группы
        return:
            HttpResponse: ответ в теле которого содержится информация о группе
        """
        return self._connection.get_data(method='group_show', args=group_name)

    def get_all_members(self, group_name: str) -> dict:
        """Возвращает словарь всех мемберов в группе"""
        group_info = self.get_group_info(group_name).json()
        members = dict()
        members["user"] = group_info.get('result').get('result').get('member_user', [])
        members["group"] = group_info.get('result').get('result').get('member_group', [])
        members["service"] = group_info.get('result').get('result').get('member_service', [])
        return members

    def _get_create_params(self) -> dict:
        method = 'group_add'
        rbtadp = self.validated_data['rbtadp']
        name = self.validated_data['name']
        params = {'rbtadp': rbtadp}
        params.update(
            {'setattr': ['='.join((key, val)) for (key, val) in self.validated_data['attributes'].items()]}
        )
        return {'method': method, 'args': name, 'params': params}

    def _get_update_params(self) -> dict:
        method = 'group_mod'
        rbtadp = self.validated_data['rbtadp']
        name = self.validated_data['name']
        params = {'rbtadp': rbtadp}
        params.update({'rename': self.validated_data['rename']})
        params.update(
            {'setattr': ['='.join((key, val)) for (key, val) in self.validated_data['attributes'].items()]}
        )
        return {'method': method, 'args': name, 'params': params}

    def _get_delete_params(self) -> dict:
        method = 'group_del'
        name = self.validated_data['name']
        return {'method': method, 'args': name}

    def chunks(self, lst, n):
        for chunk in range(0, len(lst), n):
            yield lst[chunk:chunk + n]

    def add_members(self, group_name: str, members: dict):
        """Добавление мемберов в группу.
        Добавляет только тех мемберов, которых нет в группе

        args:
            group_name (str): имя группы,
            members (dict): словарь мемберов для удаления ({"user": list, "group": list, "service": list})

        return:
            res (HttpResponse): возвращает результат операции удаления мемберов

        raise:
            AddMemberException: если не удалось добавить мемберы
        """
        members = [
            *list(set(members['user']).difference(self._members["user"])),
            *list(set(members['group']).difference(self._members["group"])),
            *list(set(members['service']).difference(self._members["service"]))
        ]
        for ob in self.chunks(members, 1000):
            count_members = len(ob)
            try:
                res = self._connection.insert_data(
                    method='group_mod',
                    args=group_name,
                    params={
                        'addattr': ob
                    }
                )
            except Exception as e:
                logger.error(e)
                raise AddMemberException("Ошибка добавления мемберов в группу")
            logger.debug(f"Количество мемберов для добавления в группу: {count_members}")
            logger.debug(res.json())
            if res.json().get('error', {}) and  res.json().get('error').get('code') != 4202:
                logger.error(f"Ошибка добавления мемберов в группу. Не все мемберы добавились: {res.json().get('error')}")
            return res

    @raise_for_error
    def delete_members(self, group_name: str,  members: dict):
        """Удаление мемберов из группы.
        Удаляет только тех мемберов, которых нет в self.validated_data["user_member"]

        args:
            group_name (str): имя группы

        return:
            res (HttpResponse): возвращает результат операции удаления мемберов
        """
        user_members = list(set(self._members["user"]).difference(members['user']))
        group_members = list(set(self._members["group"]).difference(members['group']))
        service_members = list(set(self._members["service"]).difference(self.validated_data["service_member"]))
        try:
            res = self._connection.insert_data(
                method='group_remove_member',
                args=group_name,
                params={
                    'user': user_members,
                    'group': group_members,
                    'service': service_members
                }
            )
        except Exception as e:
            logger.error(e)
            raise ClearMembersException("Не удалось удалить мемберов из группы")
        return res

    def check_members(self, method: str, members: list, members_category: str, pk: str):
        """Проверка существования мемберов в системе.
        Проверяются только те мемберы которых нет в группе.

        args:
            method (str): метод для поиска мембера (user_find, group_find, service_find)
            members (list): список мемберов для проверки
            members_category (str): категория мемберов (user, group, service)

        return:
            result (list): список проверенных мемберов

        raise:
            CheckMemberException: если мембера нет в системе
        """
        parent = list(ModelVirtualTreeLDAP.objects.filter(master_i_d__in=members).values_list('slave_i_d', flat=True))
        result = list()
        for member in parent:
            for repeat in range(1):
                res = self._connection.insert_data(
                    method=method,
                    args=[],
                    params={'nsuniqueid': member}
                )
                if res.json().get('result', {}).get("result", None):
                    result.append(res.json().get('result', {}).get("result", None)[0].get(pk)[0])
                    break
            else:
                logger.error(f"Не удалось получить member {member}.")
        return result

    def to_internal_value(self, data):
        result = dict()
        result['name'] = data.get('object_name', None)
        result['slave_i_d'] = data.get('slave_i_d', None)

        parent_guid = data.get("parent")
        parent_new_guid = data.get("parent_new")
        dn_parent = self.get_parent_dn(parent_guid, 'orgunit_find', 'dn', data['structure_i_d']['dn_rx'])
        if parent_guid == parent_new_guid:
            dn_parent = dn_parent
        else:
            dn_parent = self.get_parent_dn(parent_new_guid, 'orgunit_find', 'dn', data['structure_i_d']['dn_rx'])
        result['rbtadp'] = self.get_parent_ou(dn_parent, data['structure_i_d']['dn_rx'])
        members = data['master_attributes'].pop('member', [])
        result['user_member'] = members.get('user', [])
        result['group_member'] = members.get('group', [])
        result['service_member'] = members.get('service', [])
        result['rename'] = data.get('object_name_new', result['name'])
        result['attributes'] = data.get('master_attributes').get("attributes", {})
        if result['slave_i_d']:
            result['name'] = self.entry_find('group_find', 'cn', result['slave_i_d'])
        return super().to_internal_value(result)

    def _pre_update(self):
        root_dn = re.search(r'(?<=cn=accounts).*', self.initial_data['structure_i_d']['dn_rx']).group(0)
        user_dn = f'{self.user_prefix}{root_dn}'
        group_dn = f'{self.group_prefix}{root_dn}'
        service_dn = f'{self.service_prefix}{root_dn}'
        self._members = self.get_all_members(self.validated_data.get('name'))
        logger.info("Проверка существования участников для группы. Может занять продолжительное время!")
        members = {'user': self.check_members(
            'user_find',
            self.validated_data.get('user_member'),
            'user',
            'uid'
        )}
        members.update({'group': self.check_members(
            'group_find',
            self.validated_data.get('group_member'),
            'group',
            'cn'
        )})
        members.update({'service': self.check_members(
            'service_find',
            self.validated_data.get('service_member'),
            'service',
            'krbprincipalname'
        )})
        logger.info("Проверка существования меберов прошла успешно")
        logger.info("Удаление мемберов из группу. Может занять продолжительное время!")
        self.delete_members(group_name=self.validated_data.get('name'), members=members)
        logger.info("Удаление мемберов прошло успешно")
        logger.info("Добавление мемберов в группу. Может занять продолжительное время!")
        members['user'] = [f"member=uid={i},{user_dn}" for i in members['user']]
        members['group'] = [f"member=cn={i},{group_dn}" for i in members['group']]
        members['service'] = [f"member=krbprincipalname={i},{service_dn}" for i in members['service']]
        res = self.add_members(group_name=self.validated_data.get('name'), members=members)
        logger.info("Добавление мемберов в группу прошло успешно")
        return res


class OrgUnitIPASerializer(BaseUnitSerializer):
    name_unit = 'organizationalUnit'
    type_unit = 'ALD'

    parentou = serializers.CharField()
    dn = serializers.CharField()
    name = serializers.CharField()
    parentou_new = serializers.CharField()
    name_new = serializers.CharField()
    attributes = serializers.JSONField()
    slave_i_d = serializers.CharField(allow_null=True, allow_blank=True)

    def recalculate_slave_i_d(self, slaves_id_map):
        orgunits = ModelVirtualTreeLDAP.objects.filter(slave_i_d__in=list(slaves_id_map.keys()))
        for orgunit in orgunits:
            orgunit.slave_i_d = slaves_id_map[orgunit.slave_i_d]
        ModelVirtualTreeLDAP.objects.bulk_update(orgunits, ["slave_i_d"], batch_size=10_000)

    def _post_update(self):
        logger.info("OrgUnit post update")
        new_ou = f"ou={self.validated_data['name_new']},{self.validated_data['parentou_new']}"
        name_ou = self.validated_data['name_new']
        old_ou = f"ou={self.validated_data['name']},{self.validated_data['parentou']}"
        if not new_ou == old_ou:
            ou = UpdateOu(
                session=self._connection._strategy,
                name_ou=name_ou,
                new_ou=new_ou,
                old_ou=old_ou
            )
            # move org unit from old_ou to new_ou with name name_ou
            ou.ou_find()
            self.recalculate_slave_i_d(ou._slaves_id_map)
    
    def _get_create_params(self) -> dict:
        method = 'orgunit_add'
        name = self.validated_data['name']
        parentou = self.validated_data['parentou']
        params = dict()
        params.update({'parentou': parentou})
        params.update(
            {'setattr': ['='.join((key, val)) for (key, val) in self.validated_data['attributes'].items()]}
        )
        return {'method': method, 'args': name, 'params': params}


    def _get_update_params(self) -> dict:
        method = 'orgunit_mod'
        name = self.validated_data['name']
        parentou = self.validated_data['parentou']
        params = dict()
        params.update({'parentou': parentou})
        params.update(
            {'setattr': ['='.join((key, val)) for (key, val) in self.validated_data['attributes'].items()]}
        )
        return {'method': method, 'args': name, 'params': params}

    def _get_delete_params(self) -> dict:
        method = 'orgunit_del'
        ou = self.validated_data['dn'].replace('"', "\\22")
        params = {'force': True}
        return {'method': method, 'args': ou, 'params': params}

    def _validate_new_dn(self, attrs):
        new_ou = f"ou={attrs['name_new']},{attrs['parentou_new']}"
        old_ou = f"ou={attrs['name']},{attrs['parentou']}"
        if not new_ou.lower() == old_ou.lower():
            parent_new = re.sub(',cn=orgunits.*', '', attrs['parentou_new'].lower())
            ou = attrs['name_new']
            params = {'parentou': parent_new, 'ou': ou}
            res = self._connection.get_data(
                **{'method': 'orgunit_find', 'args': [], 'params': params}
            )
            if res.json().get('result', {}).get("count", 0):
                raise IPAException("Duplicate Org Unit", error_code=4002)

    def validate_attributes(self, value):
        manager = value.pop('manager', None)
        if manager:
            manager = ModelVirtualTreeLDAP.objects.filter(master_i_d=manager).first()
        if manager:
            if manager.execute:
                manager = f"uid={manager.object_name}"
            else:
                manager = f"uid={manager.object_name_new}"
            manager = ','.join([manager, 'cn=users', self._accounts_dn])
            value['manager'] = manager
        else:
            value.pop('manager', None)
        return value

    def validate(self, attrs):
        self._validate_new_dn(attrs)
        return super().validate(attrs)

    def to_internal_value(self, data):
        self._accounts_dn = re.findall('cn=accounts.*', data['structure_i_d']['dn_rx'])[0]
        result = dict()
        result['name'] = data.get('object_name', None)
        result['slave_i_d'] = data.get('slave_i_d', None)
        parent_guid = data.get("parent")
        parent_new_guid = data.get("parent_new")
        dn_parent = self.get_parent_dn(parent_guid, 'orgunit_find', 'dn', data['structure_i_d']['dn_rx'])
        if parent_guid == parent_new_guid:
            dn_parent_new = dn_parent
        else:
            dn_parent_new = self.get_parent_dn(parent_new_guid, 'orgunit_find', 'dn', data['structure_i_d']['dn_rx'])
        if result['slave_i_d']:
            result['name'] = self.entry_find('orgunit_find', 'ou', result['slave_i_d'], True)
        result['parentou'] = self.get_parent_ou(dn_parent, data['structure_i_d']['dn_rx'])
        result['name_new'] = data['object_name_new'] if data.get('object_name_new', None) else result['name']
        result['parentou_new'] = self.get_parent_ou(dn_parent_new, data['structure_i_d']['dn_rx'])
        result['dn'] = ','.join([f"ou={result['name']}", result['parentou_new']])
        result['attributes'] = data.get('master_attributes').get("attributes", {})
        display_name = result['attributes'].get('displayname', None)
        result['attributes']['displayname'] = display_name if display_name else result['name']
        return super().to_internal_value(result)


class UserIPASerializer(BaseUnitSerializer):
    name_unit = 'user'
    type_unit = 'ALD'

    krbpasswordexpiration_period = 60
    name = serializers.CharField()
    object_name_new = serializers.CharField(allow_null=True, allow_blank=True)
    rbtadp = serializers.CharField(required=False)
    givenname = serializers.CharField(allow_null=True, allow_blank=True)
    sn = serializers.CharField(allow_null=True, allow_blank=True)
    cn = serializers.CharField(allow_null=True, allow_blank=True)
    password = serializers.CharField(allow_null=True, allow_blank=True)
    proxyaddresses = serializers.ListField(child=serializers.CharField(), allow_null=True)
    attributes = serializers.JSONField()
    slave_i_d = serializers.CharField(allow_null=True, allow_blank=True)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._proxyaddresses = []
        self._epwd = None
        self.res = None

    def passwd_field_name(self):
        """
        Return name of fields for password attr
        """
        return "userParameters"

    def _decripted_password(self, jstr: str) -> (str, str):
        """Возвращает расшифрованный пароль и сообщение для лога или вызывает исключение.
        Args:
            jstr (str): строка с зашифрованным паролем
        Return:
            (str, str):  расшифрованный пароль и сообщения для логгера (если имеется)
        Raise:
            raise LibPassDecDecryptPasswordError: если не удалось расшифровать
        """
        pass_enc = PassEncryption()
        password_dict = json.loads(jstr)
        kvno = password_dict['kvnopub']
        key_model = get_object_or_404(ModelOptionsKey, kvno=kvno)
        pkey = key_model.private_key
        return pass_enc.decrypt_password(jstr=jstr, pkey=pkey.encode())

    def _get_create_params(self) -> dict:
        method = 'user_add'
        name = self.validated_data['name']
        params = dict()
        params.update(
            {'givenname': self.validated_data['givenname']} if self.validated_data['givenname'] else {'givenname': name}
        )
        params.update(
            {'sn': self.validated_data['sn']} if self.validated_data['sn'] else {'sn': '-'}
        )
        params.update(
            {'cn': self.validated_data['cn']} if self.validated_data['cn'] else {}
        )
        params.update(
            {'rbtadp': self.validated_data['rbtadp']} if self.validated_data['rbtadp'] else {}
        )
        params.update(
            {'proxyaddresses': self.validated_data['proxyaddresses']} if self.validated_data['proxyaddresses'] else {}
        )

        params.update(
            {'userpassword': self.validated_data["password"]} if self.validated_data["password"] else {})

        params.update({'epwd': self._epwd})

        params.update(
            {'setattr': ['='.join((key, val)) for (key, val) in self.validated_data['attributes'].items()]}
        )
        return {'method': method, 'args': name, 'params': params}

    def _get_update_params(self) -> dict:
        method = 'user_mod'
        name = self.validated_data['name']
        object_name_new = self.validated_data["object_name_new"]
        params = dict()
        proxyaddresses = list(filter(
            lambda proxy: re.match('([a-z]+:[a-z]+)|([A-Z]+:[A-Z]+)', proxy),
            self._proxyaddresses
        ))
        proxyaddresses.extend(
            self.validated_data['proxyaddresses'] if self.validated_data['proxyaddresses'] else []
        )
        params.update(
            {'proxyaddresses': proxyaddresses if proxyaddresses else []}
        )
        params.update(
            {'givenname': self.validated_data['givenname']} if self.validated_data['givenname'] else {}
        )
        params.update(
            {'sn': self.validated_data['sn']} if self.validated_data['sn'] else {'sn': '-'}
        )
        params.update(
            {'cn': self.validated_data['cn']} if self.validated_data['cn'] else {}
        )
        params.update(
            {'rbtadp': self.validated_data['rbtadp']} if self.validated_data['rbtadp'] is not None else {}
        )
        params.update(
            {'userpassword': self.validated_data["password"]} if self.validated_data["password"] else {}
        )

        params.update(
            {'setattr': ['='.join((key, val)) for (key, val) in self.validated_data['attributes'].items()]}
        )
        if object_name_new and not name == object_name_new:
            params["setattr"].append(f"uid={object_name_new}")

        return {'method': method, 'args': name, 'params': params}

    def _post_create(self):
        method = 'user_mod'
        name = self.validated_data['name']
        params = dict()
        proxy = self.res.json().get('result', {}).get('result', {}).get('proxyaddresses', None)
        if not proxy:
            mail = self.res.json().get('result', {}).get('result', {}).get('mail', None)
            if mail:
                params.update({'proxyaddresses': f"SMTP:{mail[0].upper()}"})
        if self.validated_data['password']:
            krbpasswordexpiration = datetime.now() + timedelta(days=self.krbpasswordexpiration_period)
            params.update({'krbpasswordexpiration': krbpasswordexpiration.strftime('%Y%m%d%H%M%SZ')})

        return self._connection.insert_data(method=method, args=name, params=params)

    def _post_update(self):
        if self.validated_data['password']:
            method = 'user_mod'
            name = self.validated_data['name']
            params = dict()
            krbpasswordexpiration = datetime.now() + timedelta(days=self.krbpasswordexpiration_period)
            params.update({'krbpasswordexpiration': krbpasswordexpiration.strftime('%Y%m%d%H%M%SZ')})

            return self._connection.insert_data(method=method, args=name, params=params)

    def _pre_update(self):
        method = 'user_show'
        name = self.validated_data['name']
        params = {'all': True}
        res = self._connection.get_data(method=method, args=name, params=params)

        proxyaddresses = res.json().get('result', {}).get('result', {}).get('proxyaddresses', [])
        self._proxyaddresses = proxyaddresses
        return res

    def _get_delete_params(self) -> dict:
        method = 'user_del'
        name = self.validated_data['name']
        params = dict()
        return {'method': method, 'args': name, 'params': params}

    def _validate_mail(self, attributes):
        mail = attributes.get('mail', None)
        if not mail:
            attributes.pop('mail', None)
        return attributes

    def validate_attributes(self, value):
        value = self._validate_mail(value)
        manager = value.get('manager', None)
        if manager:
            manager = ModelVirtualTreeLDAP.objects.filter(master_i_d=manager).first()
        if manager:
            value['manager'] = manager.object_name
        else:
            value.pop('manager', None)
        for key in value.keys():
            if value[key] is True:
                value[key] = 'true'
            elif value[key] is False:
                value[key] = 'false'
        return value

    def validate_password(self, value):
        if not value:
            return None
        password = value
        try:
            password, msg = self._decripted_password(password)
            if msg:
                logger.warning(msg)
        except:
            logger.warning("Не удалось расшифровать пароль пользователя")
            password = None
        finally:
            return password

    def to_internal_value(self, data):
        data['name'] = data.get('object_name', None)
        data['slave_i_d'] = data.get('slave_i_d', None)
        parent_guid = data.get("parent")
        parent_new_guid = data.get("parent_new")
        dn_parent = self.get_parent_dn(parent_guid, 'orgunit_find', 'dn', data['structure_i_d']['dn_rx'])
        if parent_guid == parent_new_guid:
            dn_parent = dn_parent
        else:
            dn_parent = self.get_parent_dn(parent_new_guid, 'orgunit_find', 'dn', data['structure_i_d']['dn_rx'])
        data['rbtadp'] = self.get_parent_ou(dn_parent, data['structure_i_d']['dn_rx'])
        data['givenname'] = data['master_attributes'].get("attributes", {})\
            .pop('givenname', data['name'])
        data['sn'] = data['master_attributes'].get("attributes", {}).pop('sn', None)
        data['cn'] = data['master_attributes'].get("attributes", {}).pop('cn', None)
        data['password'] = data['master_attributes'].get("attributes", {}).pop('userParameters', None)
        self._epwd = data['password'] if data['password'] else ""
        proxyaddresses = data['master_attributes'].get("attributes", {}).pop('proxyaddresses', None)
        data['proxyaddresses'] = proxyaddresses if proxyaddresses else []
        data['attributes'] = data.get('master_attributes').get("attributes", {})
        if data['slave_i_d']:
            data['name'] = self.entry_find('user_find', 'uid', data['slave_i_d'])
        return super().to_internal_value(data)


class UserADSerializer(BaseUnitSerializer):
    name_unit = 'user'
    type_unit = 'AD'

    name = serializers.CharField()
    password = serializers.CharField(allow_null=True, allow_blank=True)
    dn = serializers.CharField(allow_null=True, allow_blank=True)

    def _decripted_password(self, jstr: str) -> str:
        """
        Function decripted password user from key string
        """
        pass_enc = PassEncryption()
        password_dict = json.loads(jstr)
        kvno = password_dict['kvnopub']
        key_model = get_object_or_404(ModelOptionsKey, kvno=kvno)
        pkey = key_model.private_key
        return pass_enc.decrypt_password(jstr=jstr, pkey=pkey.encode())

    def validate_password(self, value):
        if not value:
            return None
        password = value
        try:
            password, msg = self._decripted_password(password)
            if msg:
                logger.warning(msg)
            password = f'\"{password}\"'
            password = password.encode('utf-16-le')
        except:
            logger.warning("Не удалось расшифровать пароль пользователя")
            password = None
        finally:
            return password

    def passwd_field_name(self):
        """
        Return name of fields for password attr
        """
        return "epwd"

    def _post_update(self):
        pass

    def _get_create_params(self) -> dict:
        pass

    def _get_delete_params(self) -> dict:
        pass

    def _get_update_params(self) -> tuple:
        add_pass = [
            (MOD_REPLACE, 'unicodePwd', [self.validated_data["password"]])
        ]
        return self.validated_data.get('dn'), add_pass

    def update(self):
        logger.debug(f"update params: {self.data['update']}")
        self._pre_update()
        res = self._connection.update_data(*self.data['update'])
        self._post_update()
        return res

    def to_internal_value(self, data):
        data['name'] = data.get('object_name', None)
        master_guid = data.get("master_i_d")
        data['dn'] = self.get_dn_by_guid(master_guid)
        data['password'] = data['slave_attributes'].get("attributes", {}).pop('epwd', None)
        data['attributes'] = data.get('slave_attributes').get("attributes", {})
        return super().to_internal_value(data)

create_dict_serializers_classes()
