import typing
import uuid
from abc import ABC, abstractmethod
from datetime import datetime, timedelta

from django.utils.timezone import make_aware

from provider.models import ModelProviderTxRx, ModelVirtualTreeLDAP, ModelGlobalTimeDeleted, ModelProviderStatus
from services.options.options import get_auth_options
from services.provider.provider import Provider
from services.provider.strategy import ProviderStrategiesDict
from services.const.const import FLT_OBJECTS, DELTA_TIME_CHECKING_IS_CHANGED, MIN_DATA_LDAP
from services.watcher.serializers import VirtualTreeADBaseSerializer, WatcherSerializers
from services.watcher.exceptions import WatcherEPWDException, ObjectDoesNotExistInDataBase

import logging

logger = logging.getLogger(__name__)


class BaseWatcherRunner(ABC):
    @abstractmethod
    def delete_object_virtual_tree(self, options: ModelProviderTxRx):
        ...

    @abstractmethod
    def get_provider(self) -> Provider:
        ...

    @abstractmethod
    def get_filter_ldap(self) -> str:
        ...

    @abstractmethod
    def get_datetime_sync_begin(self) -> str:
        ...

    @abstractmethod
    def get_sync_data(self, filter_ldap: str) -> typing.Generator:
        ...

    @abstractmethod
    def syncing_data(self, gen: typing.Generator):
        ...

    @abstractmethod
    def syncing_gen_iter(self, raw_ldap_objects: list, changed: datetime) -> datetime:
        ...

    @abstractmethod
    def run(self):
        ...


class WatcherRunner(BaseWatcherRunner):

    DATE_MODIFY_FIELD_NAME = "whenChanged"

    def __init__(self, tx_rx: ModelProviderTxRx):
        self._tx_rx = tx_rx
        self._options = None
        self._provider = self.get_provider()

    def get_provider(self) -> Provider:
        """
        Bind provider for syncing
        """
        self._options = get_auth_options(self._tx_rx.options_tx)
        provider = Provider(ProviderStrategiesDict[self._options['type']]['LDAP']())
        provider.bind(options_bind=self._options)
        return provider

    def delete_object_virtual_tree(self, options: ModelProviderTxRx):
        """
        Syncing delete objects from AD
        options: options for provider
        """
        logger.info(f"Синхронизация удаленных объектов из {self.__class__.__name__} {options.options_tx.host}")
        ModelVirtualTreeLDAP.objects.filter(execute=False, status__status='deleted').delete()

        query_date = ModelGlobalTimeDeleted.objects.filter(
            source_data_deleted=options.options_tx
        ).first()
        if query_date is None:
            last_deleted = make_aware(datetime.now())
        else:
            last_deleted = query_date.time_last_deleted

        filter_ldap_deleted_objects = f'(&(isDeleted=TRUE)(whenChanged>={last_deleted.strftime("%Y%m%d%H%M%S")}.0Z)' \
                                      f'{FLT_OBJECTS})'
        logger.debug(f"Фильтр для поиска удаленных объектов: {filter_ldap_deleted_objects}")
        results = self._provider.search_with_pagination(
            filter_ldap=filter_ldap_deleted_objects,
            deletion=True,
            pagination=True
        )
        while True:
            try:
                res_del = next(results)
                for del_obj in res_del:
                    try:
                        if 'objectGUID' in del_obj[1]:
                            data = uuid.UUID(bytes_le=del_obj[1]['objectGUID'][0])
                            try:
                                query = ModelVirtualTreeLDAP.objects.get(master_i_d=str(data))
                                logger.debug(f"Удаленный объект в AD {query.object_name}")
                                if last_deleted is None:
                                    last_deleted = query.master_changed
                                elif last_deleted < query.master_changed:
                                    last_deleted = query.master_changed
                            except ModelVirtualTreeLDAP.DoesNotExist:
                                query = None
                            if query:
                                query.status = ModelProviderStatus.objects.get(status='deleted')
                                query.execute = True
                                query.save()
                    except:
                        logger.warning(f"Ошибка отметки объекта для удаления {del_obj}")
                        continue
            except StopIteration:
                logger.warning(f"Stop Iteration Watcher Delete objects {self.__class__.__name__}")
                break
            except Exception as e:
                logger.error(e)
                logger.exception(e)
                continue

        if query_date is not None:
            query_date.time_last_deleted = last_deleted
            query_date.save()
        else:
            ModelGlobalTimeDeleted.objects.create(
                time_last_deleted=last_deleted,
                source_data_deleted=options.options_tx
            )

    def get_datetime_sync_begin(self) -> datetime:
        """
        Get time begin syncing.
        return: datetime object
        """
        if self._tx_rx.time_changed:
            changed = self._tx_rx.time_changed
        else:
            changed = make_aware(datetime(2000, 1, 1, 1, 1, 1, 1))
        logger.info(
            f"Time begin syncing from {self.__class__.__name__}: "
            f"{changed.strftime('%Y-%m-%d %H:%M:%S')}"
        )
        return changed

    def get_filter_ldap(self) -> str:
        """
        Get filter for ldap get syncing objects.
        return: string filter
        """
        if self._tx_rx.time_changed:
            last_update = self._tx_rx.time_changed + timedelta(seconds=DELTA_TIME_CHECKING_IS_CHANGED)
            last_update = f'{last_update.strftime("%Y%m%d%H%M%S")}.0Z'
            filter_ldap = f'(&(whenChanged>={last_update}){FLT_OBJECTS})'
        else:
            filter_ldap = FLT_OBJECTS
        return filter_ldap

    def get_sync_data(self, filter_ldap: str) -> typing.Generator:
        """
        Get data for syncing from LDAP
        return: generator objects from LDAP
        """
        logger.info(f"Get syncing data from {self.__class__.__name__} with ldap filter: {filter_ldap}")
        res = self._provider.search_with_pagination(
            base_ou=self._tx_rx.dn_tx,
            filter_ldap=filter_ldap,
            pagination=True
        )
        return res

    @staticmethod
    def get_object_class(obj: list) -> str:
        """
        Get object class name from object.
        return: string class name
        """
        object_class = obj[1]['objectClass'][-1].decode()
        return object_class

    @staticmethod
    def str_to_date(date: str) -> datetime:
        """Convert str to datetime object
        args:
            date (str): string for template "%Y%m%d%H%M%SZ"
        return:
            result (datetime): datetime object
        """

        result = datetime.strptime(date, "%Y%m%d%H%M%S.0Z")
        result = make_aware(result)
        return result

    def syncing_gen_iter(self, raw_ldap_objects: list, changed: datetime) -> datetime:
        """
        Syncing iteration from generator
        """
        logger.info(f"Count objects of syncing in iter: {len(raw_ldap_objects)}")
        for raw_ldap_object in raw_ldap_objects:
            try:
                try:
                    object_class = self.get_object_class(raw_ldap_object)
                except:
                    logger.error("Не известный класс объекта")
                    continue
                try:
                    dn = raw_ldap_object[0]
                    if dn.lower() == self._tx_rx.dn_tx.lower():
                        continue
                    logger.debug(f"DN: {dn}")
                except:
                    logger.debug("Не возможно определить DN объекта")
                virtual_tree_serializer = WatcherSerializers[self._options['type']][object_class]
                virtual_tree_serializer = virtual_tree_serializer(
                    data=raw_ldap_object[1],
                    connection=self._provider,
                    tx_rx=self._tx_rx,
                )
                if virtual_tree_serializer.is_continue():
                    logger.info("Не синхронизировать текущие изменения. Объект в блокировке.")
                    unit_modify_date = raw_ldap_object[1][self.DATE_MODIFY_FIELD_NAME][0].decode()
                    unit_modify_date = self.str_to_date(unit_modify_date)
                    if changed <= unit_modify_date:
                        changed = unit_modify_date + timedelta(seconds=1)
                    continue
                virtual_tree_serializer.is_valid(raise_exception=True)
                virtual_tree_serializer.save()
                if changed < virtual_tree_serializer.instance.master_changed:
                    changed = virtual_tree_serializer.instance.master_changed + timedelta(seconds=1)
            except WatcherEPWDException:
                logger.warning("Отсутствует поле epwd для синхронизируемого пользователя")
            except ObjectDoesNotExistInDataBase as e:
                logger.warning(e)
            except Exception as e:
                logger.exception(e)
                continue
        return changed

    def syncing_data(self, gen: typing.Generator):
        """
        Syncing objects from LDAP.
        gen: generator objects from LDAP.
        """
        changed = self.get_datetime_sync_begin()
        while True:
            try:
                raw_ldap_objects = next(gen)
                if not raw_ldap_objects:
                    logger.error('Ошибка при получении объекта из ЛДАП')
                    break
                changed = self.syncing_gen_iter(raw_ldap_objects, changed)
            except StopIteration:
                self._tx_rx.time_changed = changed
                self._tx_rx.save()
                logger.warning(f"Stop Iteration Watcher {self.__class__.__name__}")
                break
            except Exception as e:
                logger.error(e)
                logger.exception(e)
                continue

    def run(self):
        """
        Main function for run syncing
        """
        try:
            logger.info(f"Run watcher for syncing {self.__class__.__name__}")
            self.delete_object_virtual_tree(self._tx_rx)
            filter_ldap = self.get_filter_ldap()
            gen = self.get_sync_data(filter_ldap=filter_ldap)
            self.syncing_data(gen)
            logger.info(f"Syncing {self.__class__.__name__} is SUCCESSFUL")
        except Exception as e:
            logger.critical(f'Critical error for watcher {self.__class__.__name__} syncing data.\nError: {e}')
            logger.exception(f'Critical error for watcher {self.__class__.__name__} syncing data')


class WatcherRunnerAD(WatcherRunner):
    DATE_MODIFY_FIELD_NAME = "whenChanged"


class WatcherRunnerALD(WatcherRunner):
    DATE_MODIFY_FIELD_NAME = "modifyTimestamp"

    @staticmethod
    def str_to_date(date: str) -> datetime:
        """Convert str to datetime object
        args:
            date (str): string for template "%Y%m%d%H%M%SZ"
        return:
            result (datetime): datetime object
        """

        result = datetime.strptime(date, "%Y%m%d%H%M%SZ")
        result = make_aware(result)
        return result


    @staticmethod
    def get_object_class(obj: list) -> str:
        return 'user'

    def get_filter_ldap(self) -> str:
        if self._tx_rx.time_changed:
            last_updated = f'{self._tx_rx.time_changed.strftime("%Y%m%d%H%M%S")}.0Z'
        else:
            last_updated = MIN_DATA_LDAP
        filter_ldap = f'(&(modifyTimestamp>={last_updated})(rbtadp=*{self._tx_rx.dn_tx}))'
        return filter_ldap

    def get_sync_data(self, filter_ldap: str) -> typing.Generator:
        logger.info(f"Get syncing data from {self.__class__.__name__} with ldap filter: {filter_ldap}")
        tail = self._tx_rx.dn_tx.split('cn=accounts,')[1]
        dn = f'cn=users,cn=accounts,{tail}'

        res = self._provider.search_with_pagination(
            base_ou=dn,
            filter_ldap=filter_ldap,
            search_ald=True,
            pagination=True
        )
        return res

    def run(self):
        try:
            logger.info(f"Run watcher for syncing {self.__class__.__name__}")
            filter_ldap = self.get_filter_ldap()
            gen = self.get_sync_data(filter_ldap=filter_ldap)
            self.syncing_data(gen)
            logger.info(f"Syncing {self.__class__.__name__} is SUCCESSFUL")
        except Exception as e:
            logger.critical(f'Critical error for watcher {self.__class__.__name__} syncing data.\nError: {e}')
            logger.exception(f'Critical error for watcher {self.__class__.__name__} syncing data')
