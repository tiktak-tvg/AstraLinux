import re
import logging
import copy

logger = logging.getLogger(__name__)


class UpdateOu:

    DELETE_SOFTWARE_RULES_METHOD = "softwarerule_del"
    DELETE_POLICY_RULES_METHOD = "policyrule_del"

    def __init__(self, session, old_ou, new_ou, name_ou):
        self.session = session
        old_ou = re.sub(r'..=', lambda m: m.group(0).lower(), old_ou)
        self.old_ou = old_ou
        new_ou = re.sub(r'..=', lambda m: m.group(0).lower(), new_ou)
        self.new_ou = new_ou
        self.name_ou = name_ou
        self._slaves_id_map = {}

    def modify_path(self, old_root, old_ou):
        old_root = old_root.replace('"', '\\"')
        return old_ou.replace(old_root, '')

    def modify_new_parent(self, ou):
        new_parent = ''
        for i in ou.split(',')[1:]:
            new_parent += f'{i},'
        return new_parent[:-1]

    def filter_origin_attr(self):
        parent_for_api = self.old_ou.split('cn=orgunits')[0][:-1].replace('"', "\\22")

        #Добавил all: True, для вывода вообще всего, что есть в подразделении (
        # возможна поломка, при добавлении подразделения в методе )
        resp = self.session.request(method='orgunit_find', args=[], params={'parentou': parent_for_api, 'deep': True, 'all': True})
        if not self.error_handling(resp):
            return False
        r = sorted(resp.json()['result']['result'], key=lambda s: len(s['dn']))
        return r

    def ou_find(self):
        list_obj = self.filter_origin_attr()
        if not list_obj:
            return False
        for attr in list_obj:
            attr_copy = copy.deepcopy(attr)
            if attr['dn'].lower() == self.old_ou.lower():
                new_parent_ou = ''
                for i in self.new_ou.split(',')[1:]:
                    new_parent_ou += f'{i},'
                self._slaves_id_map[attr_copy['nsuniqueid'][0]] = self.update_ou(attr, new_parent_ou[:-1], self.name_ou, self.new_ou, self.old_ou)
            else:
                old_ou = attr['dn']
                ou_root = self.modify_path(self.old_ou, old_ou)
                new_ou = f'{ou_root}{self.new_ou}'
                ou_name = attr["ou"][0]
                new_parent = self.modify_new_parent(new_ou)
                self._slaves_id_map[attr_copy['nsuniqueid'][0]] = self.update_ou(attr, new_parent, ou_name, new_ou, old_ou)

        orgunit_del = self.session.request(
            method='orgunit_del',
            args=[self.old_ou.replace('"', "\\22")],
            params={'force': True}
        )
        if not self.error_handling(orgunit_del):
            return False

    def error_handling(self, response):
        resp = response.json()
        if response.status_code != 200:
            return False
        if resp['result']:
            if resp['result']['result']:
                return True
            else:
                return False
        return False

    def update_ou(self, ou_attr, parent, ou_name, new_ou, old_ou):
        
        softwarerule = {}
        policyrule = {}
        ou = ou_attr
        
        # Заполняем словари для добавления политик
        softwarerule['memberof_softwarerule'] = ou['memberof_softwarerule'] if 'memberof_softwarerule' in ou else None
        policyrule['memberof_policyrule'] = ou['memberof_policyrule'] if 'memberof_policyrule' in ou else None
        
        # Вырезаем объекты, способные помешать махинациям с подразделениями
        # Нас ждет провал, если мы не удалим что-то, что пожет помешать добавлению подразделения
        # Например objectclass. Есть опасения, что это не все оъекты, которые нужно удалить
        ou.pop('memberof_policyrule', None)
        ou.pop('memberof_softwarerule', None)
        ou.pop('objectclass', None)
        ou.pop('parentid', None)
        ou.pop('entryid', None)
        ou.pop('dn', None)
        ou.pop('ou', None)
        ou.pop('nsuniqueid', None)
        ou['parentou'] = parent
        ou['displayname'] = [ou_name]
        
        for i in ou:
            ou[i] = ou[i][0] if type(ou[i]) == list else ou[i]
            
        ou_add = self.session.request(method='orgunit_add', args=[ou_name], params=ou)
        
        if not self.error_handling(ou_add):
            return False
        nsuniqueid = ou_add.json().get('result', {}).get('result', {}).get('nsuniqueid')

        if softwarerule['memberof_softwarerule']:
            self.delete_rules(self.DELETE_SOFTWARE_RULES_METHOD, softwarerule['memberof_softwarerule'])

        if policyrule['memberof_policyrule']:
            self.delete_rules(self.DELETE_POLICY_RULES_METHOD, policyrule['memberof_policyrule'])

        for method in ['user', 'group', 'host', 'hostgroup']:
            resp = self.session.request(method=method+'_find', args=[], params={'rbtadp': old_ou})
            if self.error_handling(resp):
                for r in resp.json()['result']['result']:
                    obj = None
                    if 'uid' in r:
                        obj = r['uid'][0]
                    elif 'fqdn' in r:
                        obj = r['fqdn'][0]
                    elif 'cn' in r:
                        obj = r['cn'][0]
                    resp_mod = self.session.request(method=method+'_mod', args=[obj], params={'rbtadp': new_ou})
                    self.error_handling(resp_mod)

        return nsuniqueid[0]

    def delete_rules(self, method: str, rules: list) -> None:
        """Функция для удаления правил политик

        @param method (str): Метод для удаления правил политик
        @param rules (list): Список правил политик
        @return: None

        """
        try:
            response = self.session.request(method=method, args=rules)
            if not self.error_handling(response):
                return None
        except:
            logger.error(f"Ошибка при удаления правил политик методом {method}")
