import json
import base64
from .c_types import *

from ctypes import cdll

lib = cdll.LoadLibrary('libpassdec.so')


class LibPassDecGenKeysError(Exception):

    def __init__(self, message, errors=None):
        super().__init__(message)
        self.errors = errors


class LibPassDecDecryptPasswordError(Exception):

    def __init__(self, message, errors=None):
        super().__init__(message)
        self.errors = errors


class PassEncryption:
    """Используется для геренации ключей,
    получения версии kvno, и расшифровки данных

    Args:
        __init__() - Загрузка библиотеки c++
        get_keys() return { 'public_key': str, 'private_key': str } - Получение открытого и закрытого ключей шифрования
        decrypt_password(jstr: Значение атрибута userParameters или epwd, pkey: Приветный ключ) return password -> str -
        расшифровка пароля
        get_kvno(jstr: Значение атрибута userParameters или epwd) return kvno - получение версии ключа
    """

    def __init__(self):

        lib.Passdec_new.restype = ctypes.c_void_p
        self.obj = lib.Passdec_new()

    def get_keys(self):

        lib.Passdec_ret.restype = result_st_t
        lib.Passdec_ret.argtypes = [ctypes.c_void_p]
        result = lib.Passdec_ret(self.obj)

        if result.status == 0:
            msg = result.errMSG.decode()
            raise LibPassDecGenKeysError(f"Ошибка генерации ключей: {msg}")

        keys_data = {'public_key': result.u.keys.public_key.decode(),
                     'private_key': result.u.keys.private_key.decode()}
        lib.Passdec_del.argtypes = [ctypes.c_void_p]
        lib.Passdec_del(self.obj)
        return keys_data

    def decrypt_password(self, jstr, pkey):

        json_l = json.loads(jstr)
        dec_data = base64.b64decode(json_l['enc_base64'])
        lib.Passdec_decrypt.restype = result_st_t
        lib.Passdec_decrypt.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int]
        result = lib.Passdec_decrypt(self.obj, ctypes.c_char_p(dec_data), ctypes.c_char_p(pkey),
                                     ctypes.c_int(int(json_l['cipher_size'])))
        msg = None
        if result.status == 0:
            msg = result.errMSG.decode()
            raise LibPassDecDecryptPasswordError(f"Ошибка при расшифровки пароля: {msg}")

        if result.errMSG:
            msg = result.errMSG.decode()

        decrypt_data = result.u.resultData.decode()
        lib.Passdec_del.argtypes = [ctypes.c_void_p]
        lib.Passdec_del(self.obj)
        return decrypt_data, msg

    def get_kvno(self, jstr):
        return json.loads(jstr)['kvnopub']
