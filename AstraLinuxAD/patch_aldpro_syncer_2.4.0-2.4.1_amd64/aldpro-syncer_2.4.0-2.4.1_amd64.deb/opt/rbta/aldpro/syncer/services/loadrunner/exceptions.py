class ParentSlaveIdNotExist(Exception):
    """raise если родительское подразделение не синхронизовалось"""


class SlaveIdNotExist(Exception):
    """raise если у объекта синхронизации нет значения в поле slave_i_d"""


class AddMemberException(Exception):
    """raise при ошибки добавления мембера в группу"""


class ClearMembersException(Exception):
    """raise при ошибки удаления мемберов из группы"""


class CheckMemberException(Exception):
    """raise если не удалось получить необходимого member из АЛД"""


class ObjectGUIDNotFindException(Exception):
    """Исключение если не удалось найти объект в лдап по objectGuid"""
