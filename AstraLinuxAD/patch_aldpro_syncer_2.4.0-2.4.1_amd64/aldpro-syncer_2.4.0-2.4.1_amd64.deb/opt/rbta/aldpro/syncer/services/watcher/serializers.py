import datetime
import uuid
from typing import Generator

import ldap.filter
from rest_framework import serializers
import inspect
import sys
import logging


from django.utils.timezone import make_aware

from provider.models import ModelVirtualTreeLDAP, ModelProviderStatus, ModelProviderTxRx
from tracer.models import ModelTracerObjectClass, ModelTracer
from services.utils.transliterate_name import transliterate_name
from services.utils.rule_processor import process_replace
from services.watcher.exceptions import WatcherEPWDException, ObjectDoesNotExistInDataBase

logger = logging.getLogger(__name__)

WatcherSerializers = dict()
WatcherSerializers.setdefault('AD', {})
WatcherSerializers.setdefault('ALD', {})


def create_dict_serializers_classes():
    for name, obj in inspect.getmembers(sys.modules[__name__]):
        if inspect.isclass(obj) and hasattr(obj, 'name_unit'):
            WatcherSerializers[obj.type_unit][obj.name_unit] = obj


class BaseUnitWatcherSerializer(serializers.ModelSerializer):
    class Meta:
        model = ModelVirtualTreeLDAP
        fields = '__all__'
        depth = 5

    def __init__(self, *args, **kwargs):
        connection = kwargs.pop('connection', None)
        tx_rx = kwargs.pop('tx_rx', None)
        super(BaseUnitWatcherSerializer, self).__init__(*args, **kwargs)
        self._connection = connection
        self._tx_rx = tx_rx


class VirtualTreeADBaseSerializer(BaseUnitWatcherSerializer):

    ERROR_DUBLICAT = '4002'
    DATE_FORMAT = '%Y%m%d%H%M%S'
    DATE_CHANGE_FIELD_NAME = 'whenChanged'
    obj_type = None

    master_created = serializers.DateTimeField(input_formats=[DATE_FORMAT])
    master_changed = serializers.DateTimeField(input_formats=[DATE_FORMAT])
    status = serializers.PrimaryKeyRelatedField(queryset=ModelProviderStatus.objects.all())
    structure_i_d = serializers.PrimaryKeyRelatedField(queryset=ModelProviderTxRx.objects.all())
    object_class = serializers.PrimaryKeyRelatedField(queryset=ModelTracerObjectClass.objects.all())

    class Meta:
        model = ModelVirtualTreeLDAP
        fields = '__all__'
        depth = 5

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        object_guid = self._get_object_guid()
        self.instance = self.get_instance(object_guid=object_guid)
        if self.instance:
            self.initial_data['status'] = ModelProviderStatus.objects.get(status='updated').pk
        else:
            self.initial_data['status'] = ModelProviderStatus.objects.get(status='created').pk

    def get_instance(self, object_guid: str) -> [ModelVirtualTreeLDAP, None]:
        """
        Get instance from VirtualTree where master_i_d == ldap object GUID
        return instance if exist
        return None if not exist
        """
        return self.Meta.model.objects.filter(master_i_d=object_guid).first()

    def _get_object_guid(self) -> str:
        """
        Get guid from ldap object in fields objectGUID
        return: GUID if exist
        raise: if not find GUID
        """

        try:
            object_guid = self.initial_data['objectGUID'][0]
            object_guid = str(uuid.UUID(bytes_le=object_guid))
            return object_guid
        except Exception as e:
            logger.error("Not define object GUID")
            raise

    def get_initial_data_changed(self):
        date = self.initial_data.get(self.DATE_CHANGE_FIELD_NAME, None)
        if date:
            date = datetime.datetime.strptime(date[0].decode().split('.')[0], self.DATE_FORMAT)
            date = make_aware(date)
        return date

    def is_continue(self) -> bool:
        """
        return True: continue without is_valid()
        return False: continue with is_valid()
        """
        if not self.instance:
            return False

        if self.instance.error:
            if self.instance.error.error_code == self.ERROR_DUBLICAT:
                logger.error(f"Блокировка: в БД ошибка  дубликата для объекта {self.instance.object_name_new}")
                self.instance.execute = False
                self.instance.save()
                return True

        if self.instance.blockpwd:
            logger.warning(f"Блокировка: в БД флаг blockpwd для объекта {self.instance.object_name_new}")
            self.instance.execute = False
            self.instance.blockpwd = False
            self.instance.save()

            return True

        date = self.get_initial_data_changed()
        if not date or self.instance.master_changed >= date:
            logger.warning(f"Блокирока: дата изменения в лдап меньше даты изменения в БД "
                           f"для объекта {self.instance.object_name_new}")
            return True

        return False

    @staticmethod
    def transliterate_name(value: str):
        return transliterate_name(value=value)

    def initial_master_attributes(self, value):
        attributes = ModelTracer.objects.select_related(
            'key_ald', 'key_ad'
        ).filter(object_class__key=self.name_unit)
        result = dict()
        master_attributes = dict()
        for attr in attributes:
            if attr.key_ad.key in value:
                result.update({attr.key_ald.key: process_replace(self.obj_type, attr.key_ald.key,value[attr.key_ad.key][0].decode().strip())})
            else:
                result.update({attr.key_ald.key: ''})
        master_attributes['attributes'] = result
        return master_attributes

    def get_parent_guid(self, dn_tx: str, dn: str) -> [str, None]:
        """
        Get parent guid for object(dn) from provider
        return: str guid
        return: None if not object == dn_tx
        """
        parent_new = ldap.filter.escape_filter_chars(dn)
        parent_dn = parent_new.lower().find("ou=", 1)
        if parent_dn == -1:
            return None

        parent_new = parent_new[parent_dn:]
        parent_new = None if dn_tx == parent_new else parent_new
        if not parent_new:
            return None

        res = self._connection.search(
            base_ou=dn_tx,
            filter_ldap=f'(|(distinguishedName={parent_new}))'
        )
        if not res:
            return None
        parent_guid = str(uuid.UUID(bytes_le=res[0][1].pop("objectGUID", None)[0]))
        parent_new = parent_guid
        return parent_new

    def validate_parent_new(self, value):
        try:
            guid = self.get_parent_guid(self._tx_rx.dn_tx, value)
        except:
            logger.warning(f"Not find parent guid for {value}")
            guid = None
        return guid

    def validate(self, attrs):
        if not self.instance:
            attrs['parent'] = attrs['parent_new']
            attrs['object_name'] = attrs['object_name_new']
        else:
            if not self.instance.execute:
                attrs['object_name'] = self.instance.object_name_new
                attrs['parent'] = self.instance.parent_new
        return super().validate(attrs)

    def set_initial_data(self, data):
        result = {
            'object_class': ModelTracerObjectClass.objects.get(key=self.name_unit).id,
            'object_name_new': data.pop('object_name', None),
            'status': data.pop('status', None),
            'execute': data.pop('execute', True),
            'structure_i_d': self._tx_rx.id,
            'master_created': data.get("whenCreated", None),
            'master_changed': data.get("whenChanged", None),
            'parent_new': data.get("distinguishedName", None),
            'master_attributes': data,
        }
        result = {k: v[0] if isinstance(v, list) else v for k, v in result.items()}
        result = {k: v.decode() if isinstance(v, bytes) else v for k, v in result.items()}
        result.update({'master_i_d': str(uuid.UUID(bytes_le=data.pop("objectGUID", None)[0]))})
        result['master_created'] = result['master_created'].split('.')[0]
        result['master_changed'] = result['master_changed'].split('.')[0]
        result['master_attributes'] = self.initial_master_attributes(result['master_attributes'])
        return result

    def to_internal_value(self, data):
        result = self.set_initial_data(data)
        data.update(result)
        result = super(BaseUnitWatcherSerializer, self).to_internal_value(data)
        return result


class VirtualTreeADUserSerializer(VirtualTreeADBaseSerializer):
    name_unit = 'user'
    type_unit = 'AD'
    obj_type = 'type-user'

    def __init__(self, *args, **kwargs):
        self._proxyaddresses = []
        super().__init__(*args, **kwargs)

    def to_internal_value(self, data):
        data['object_name'] = data.pop('sAMAccountName')
        self._proxyaddresses = data.get('proxyAddresses', [])
        data = super().to_internal_value(data)
        return data

    def validate_proxyaddresses(self, proxyaddresses: list = None) -> list:
        proxyaddresses_list = []
        for proxyaddress in proxyaddresses:
            l_proxy = proxyaddress.decode().split(':', 1)
            if len(l_proxy) > 1:
                proxyaddresses_list.append(':'.join([l_proxy[0].lower(), l_proxy[1].upper()]))
            else:
                proxyaddresses_list.append(l_proxy[-1].upper())
        return proxyaddresses_list

    def validate_master_attributes(self, value):
        if value.get('attributes', {}).get('proxyaddresses', None):
            proxyaddresses = self.validate_proxyaddresses(self._proxyaddresses)
            value['attributes']['proxyaddresses'] = proxyaddresses
        nsaccountlock = value['attributes'].pop('nsaccountlock', None)
        nsaccountlock = int(nsaccountlock)
        logger.debug(f"nsaccountlock: {nsaccountlock}")
        if nsaccountlock:
            if nsaccountlock in [512, 66048]:
                value['attributes'].update({'nsaccountlock': False})
            else:
                value['attributes'].update({'nsaccountlock': True})
        manager = value.get('attributes', {}).pop('manager', None)
        if manager:
            res = self._connection.search_base(base_ou=manager)
            manager_guid = uuid.UUID(bytes_le=res[0][1]['objectGUID'][0])
            value['attributes']['manager'] = str(manager_guid)
        return value

    def validate_object_name(self, value):
        if value:
            value = process_replace(self.obj_type, 'uid', value)
            return self.transliterate_name(value)
        return value

    def validate_object_name_new(self, value):
        if value:
            value = process_replace(self.obj_type, 'uid', value)
            return self.transliterate_name(value)
        return value


class VirtualTreeADGroupSerializer(VirtualTreeADBaseSerializer):
    name_unit = 'group'
    type_unit = 'AD'
    obj_type = 'type-group'

    def __init__(self, *args, **kwargs):
        self._members = None
        self._dn = None
        super().__init__(*args, **kwargs)

    def to_internal_value(self, data):
        data['object_name'] = data.pop('cn')
        self._dn = data.get('distinguishedName')[0].decode()
        self._members = data.pop('member', None)
        result = super().to_internal_value(data)
        return result

    def _get_members_generator(self) -> Generator:
        """Получение генератора мемберов для группы
        
        return:
            gen (Generator): генератор мемберов для группы
            None: если не удалось получить генератор
        """
        
        filter_ldap = f"(memberOf={self._dn})"
        gen = self._connection.search_with_pagination(
            filter_ldap=filter_ldap,
            pagination=True
        )
        return gen

    def _get_members(self) -> dict:
        """Пулучение списка мемберов для группы
        
        return:
            member (list): список имен мемберов
        """
        
        member = dict()
        member['user'] = []
        member['group'] = []
        member['service'] = []
        gen = self._get_members_generator()
        if not gen:
            return member
        
        while True:
            try:
                units = next(gen)
                if not units:
                    break
                for unit in units:
                    try:
                        object_class = unit[1]['objectClass'][-1].decode()
                        object_guid = str(uuid.UUID(bytes_le= unit[1]['objectGUID'][0]))
                        if object_class == 'group':
                            member['group'].append(
                                object_guid
                            )
                        else:
                            member['user'].append(
                                object_guid
                            )

                    except Exception as e:
                        continue
            except StopIteration:
                logger.debug(f"Stop Iteration: Получение объектов группы {self.__class__.__name__}")
                break
            except Exception as e:
                logger.warning(f"Не удалось получить мемберов из ЛДАП для группы {self._dn}.")
                logger.debug(f"Не удалось получить генератор мемберов из ЛДАП для группы {self._dn}.\n {e}")
        return member

    def validate_master_attributes(self, value):
        members = self._get_members()
        if members:
            value['member'] = members
        return value

    def validate_object_name(self, value):
        if value:
            value = process_replace(self.obj_type, 'cn', value)
            return self.transliterate_name(value)
        return value

    def validate_object_name_new(self, value):
        if value:
            value = process_replace(self.obj_type, 'cn', value)
            return self.transliterate_name(value)
        return value


class VirtualTreeADOrgUnitSerializer(VirtualTreeADBaseSerializer):
    name_unit = 'organizationalUnit'
    type_unit = 'AD'
    obj_type = 'type-ou'

    def to_internal_value(self, data):
        data['object_name'] = data.pop('ou')
        return super().to_internal_value(data)

    def validate_master_attributes(self, value):
        manager = value.get('attributes', {}).pop('manager', None)
        if manager:
            res = self._connection.search_base(base_ou=manager)
            manager_guid = uuid.UUID(bytes_le=res[0][1]['objectGUID'][0])
            value['attributes']['manager'] = str(manager_guid)
        return value

    def validate_object_name(self, value):
        if value:
            return process_replace(self.obj_type, 'ou', value)
        return value

    def validate_object_name_new(self, value):
        if value:
            return process_replace(self.obj_type, 'ou', value)
        return value


class VirtualTreeALDUserSerializer(VirtualTreeADBaseSerializer):
    name_unit = 'user'
    type_unit = 'ALD'

    DATE_FORMAT = '%Y%m%d%H%M%SZ'
    DATE_CHANGE_FIELD_NAME = 'modifyTimestamp'

    master_changed = serializers.DateTimeField(input_formats=['%Y%m%d%H%M%SZ'])
    structure_i_d = serializers.PrimaryKeyRelatedField(queryset=ModelProviderTxRx.objects.all())

    class Meta:
        model = ModelVirtualTreeLDAP
        fields = (
            'slave_attributes', 'execute', 'master_changed', 'blockpwd', 'structure_i_d',
            'status'
        )
        depth = 5

    def is_continue(self) -> bool:
        """
        return True: continue without is_valid()
        return False: continue with is_valid()
        """
        if not self.instance:
            logger.warning(f"Блокировка: записи об объекте нет в БД для объекта {self._get_object_guid()}")
            return True

        if self.instance.blockpwd:
            self.instance.execute = False
            self.instance.blockpwd = False
            self.instance.save()
            logger.warning(f"Блокировка: в БД флаг blockpwd для объекта {self.instance.object_name_new}")
            return True

        date = self.get_initial_data_changed()
        if not date or self.instance.master_changed >= date:
            logger.warning(f"Блокирока: дата изменения в лдап меньше даты изменения в БД "
                           f"для объекта {self.instance.object_name_new}")
            return True

        return False

    def _get_object_guid(self):
        """
        Get guid from ALD in fields nsUniqueId
        return: GUID if exist
        raise: if not find GUID
        """
        try:
            object_guid = self.initial_data['nsUniqueId'][0].decode()
            return object_guid
        except Exception as e:
            logger.error("Не возможно определить GUID объекта")
            raise

    def get_instance(self, object_guid: str) -> [ModelVirtualTreeLDAP, None]:
        """
        Get instance from VirtualTree where slave_i_d == ldap object GUID
        return instance if exist
        return None if not exist
        """
        return self.Meta.model.objects.filter(slave_i_d=object_guid).first()

    def initial_slave_attributes(self, value):
        slave_attributes = dict()
        if not value.get("epwd", None):
            raise WatcherEPWDException
        epwd = value['epwd'][0].decode()
        slave_attributes['attributes'] = dict()
        slave_attributes['attributes'].update({'epwd': epwd})

        return slave_attributes

    def set_initial_data(self, data):
        result = {
            'execute': data.pop('execute', True),
            'structure_i_d': self._tx_rx.id,
            'status': data.pop('status', None),
            'blockpwd': data.pop('blockpwd', False),
            'master_changed': data.get(self.DATE_CHANGE_FIELD_NAME, None),
            'slave_attributes': data,
        }
        result = {k: v[0] if isinstance(v, list) else v for k, v in result.items()}
        result = {k: v.decode() if isinstance(v, bytes) else v for k, v in result.items()}
        result['master_changed'] = result['master_changed'].split('.')[0]
        result['slave_attributes'] = self.initial_slave_attributes(result['slave_attributes'])
        return result

    def validate(self, attrs):
        return attrs


create_dict_serializers_classes()
