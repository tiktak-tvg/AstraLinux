from provider.models import (
    ModelProviderTxRx,
)

from services.watcher.runners import WatcherRunnerAD, WatcherRunnerALD

import logging

logger = logging.getLogger(__name__)


def watcher(revers: bool):
    queryset = ModelProviderTxRx.objects.select_related(
        'options_tx', 'options_tx__type'
    ).prefetch_related(
        'options_tx__replica'
    ).filter(is_reversed=revers)
    for item in queryset:
        if item.options_tx.type.type == 'AD':
            watcher_ad(item)
        elif item.options_tx.type.type == 'ALD':
            watcher_ald(item)


def watcher_ald(tx_rx):
    watcher_run = WatcherRunnerALD(tx_rx=tx_rx)
    watcher_run.run()


def watcher_ad(tx_rx):
    watcher_run = WatcherRunnerAD(tx_rx=tx_rx)
    watcher_run.run()

