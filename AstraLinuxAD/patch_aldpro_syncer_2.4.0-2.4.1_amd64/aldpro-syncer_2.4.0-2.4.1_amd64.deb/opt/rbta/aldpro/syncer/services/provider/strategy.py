import os.path
import inspect
import sys
import typing

from abc import ABC, abstractmethod
from typing import Dict, List
import ldap
from ldap.controls.pagedresults import SimplePagedResultsControl
import logging

from syncer.exceptions import LDAPConnectionError
from .exception import NotConnectedToProvider
from services.ipa.api.Api import Api
from requests.exceptions import RequestException
from django.conf import settings


logger = logging.getLogger(__name__)


def raise_for_status(func):
    def wrapper(*args, **kwargs):
        res = func(*args, **kwargs)
        res.raise_for_status()
        return res
    return wrapper


ProviderStrategiesDict = dict()
ProviderStrategiesDict.setdefault('AD', {})
ProviderStrategiesDict.setdefault('ALD', {})


def create_dict_strategies_classes():
    for name, obj in inspect.getmembers(sys.modules[__name__]):
        if inspect.isclass(obj) and hasattr(obj, 'name_unit'):
            ProviderStrategiesDict[obj.type_unit][obj.name_unit] = obj


class ProviderStrategy(ABC):

    @abstractmethod
    def do_bind(self, options_bind: Dict) -> None:
        pass

    @abstractmethod
    def do_unbind(self):
        pass

    @abstractmethod
    def do_search(self, base_ou: str = None, filter_ldap: str = None) -> List:
        pass

    def do_search_user_ald(self, root: str = None, filter_ldap: str = None) -> List:
        pass

    @abstractmethod
    def do_search_base(self, base_ou: str = None, filter_ldap: str = None) -> List:
        pass

    def do_search_deleted(self, base_ou: str = None, filter_ldap: str = None) -> List:
        pass

    @abstractmethod
    def get_hosts_dc(self) -> List:
        pass

    @abstractmethod
    def get_org_units(self, base_ou: str = '', deep: bool = True) -> List:
        pass

    @abstractmethod
    def do_insert_data(self, *args, **kwargs):
        pass

    @abstractmethod
    def do_update_data(self, *args, **kwargs):
        pass

    @abstractmethod
    def do_get_data(self, *args, **kwargs):
        pass


class ProviderLDAPStrategy(ProviderStrategy):

    SEARCH_DC_DIRECTORY_NAME = 'OU=Domain Controllers'  # ldap directory for dc replicas
    SEARCH_DC_FILTER = '(|(CN=*))'  # filter for find names dc replicas
    DEFAULT_NAMING_CONTEXT_KEY = 'defaultnamingcontext'  # key for get root dn
    SEARCH_ORG_UNIT_FILTER = '(|(objectClass=organizationalUnit))'  # filter for find organizationl units
    NAMING_REPLICA_DOMAIN_KEY = 'cn'  # key for get replica name from result
    SERVICE_DN_TEMPLATE = "uid={},cn=sysaccounts,cn=etc,{}"
    USER_DN_TEMPLATE = "uid={},cn=users,cn=accounts,{}"

    def __init__(self):
        self._connect = None
        self._root_dn = None  # root domain name
        self.delcontr = ldap.controls.simple.ValueLessRequestControl('1.2.840.113556.1.4.417', True)

    def get_base_dn_from_host(self, hostname: str) -> str:
        """получение базовой DN из имени хоста
        Args:
            hostname (str): имя хоста
        Return:
            (str): базовая DN
        """
        return ','.join(f"dc={x}" for x in hostname.split('.')[1:])

    def get_realm(self, hostname: str):
        """Получение имени домена из имени хоста
        Args:
            hostname (str): имя хоста
        Return:
            (str): имя домена
        """
        if hostname.count(".") >= 2:
            return hostname.split('.', 1)[1].upper()
        else:
            return hostname

    def get_login(self, user: str, host: str):
        """Получение dn для авторизации в ЛДАП
        Args:
            user (str): имя пользователя
            host (str): имя хоста
        Return:
            (str): dn для пользователя для авторизации в ЛДАП
        """
        host = self.get_base_dn_from_host(host)
        if "/" in user:
            return self.SERVICE_DN_TEMPLATE.format(user, host)
        else:
            return self.USER_DN_TEMPLATE.format(user, host)

    def _check_tls_key_file(self, id) -> str:
        """
        Check tls key file with name {provider_id}.pem.
        Return file path, raise exception if else
        """
        tls_key_file = os.path.join(settings.PROVIDER_TLS_KEY_DIR, f"key{id}.pem")
        if not os.path.exists(tls_key_file):
            raise AttributeError(f"Not key file for provider id={id}")
        return tls_key_file

    def do_bind(self, options_bind: Dict) -> None:
        logger.debug(f"Try bind for {options_bind['host']}")
        hosts = list()
        hosts.append(options_bind['host'])
        hosts.extend(options_bind.get('replica', []))
        hosts = list(dict.fromkeys(hosts))
        key_file = self._check_tls_key_file(options_bind['id'])
        user = options_bind['user']
        user = self.get_login(user,  options_bind['host'])
        
        for host in hosts:
            self._connect = ldap.initialize(f"ldap://{host}")
            self._connect.set_option(ldap.OPT_X_TLS_CACERTFILE, key_file)
            self._connect.set_option(ldap.OPT_REFERRALS, 0)
            self._connect.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
            self._connect.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
            self._connect.set_option(ldap.OPT_DEBUG_LEVEL, 255)
            self._connect.set_option(ldap.OPT_X_TLS_NEWCTX, 0)
            
            try:
                self._connect.start_tls_s()
                self._connect.simple_bind_s(user, options_bind['password'])
                logger.debug(f"Connect to provider host {host} is successful. Protocol LDAP")
            except ldap.LDAPError as e:
                logger.error(e)
            else:
                break
                
        else:
            raise LDAPConnectionError(f'Not connect to provider {options_bind["host"]}. Protocol LDAP') from None
        
        # Get root domain name from server
        self._root_dn = self._connect.read_rootdse_s().get(self.DEFAULT_NAMING_CONTEXT_KEY)[0].decode()

    def do_unbind(self):
        try:
            self._connect.unbind_s()
        except ldap.LDAPError:
            raise
        return

    def do_search_with_pagination(self,
                                  base_ou: str = None,
                                  filter_ldap: str = None,
                                  deletion: bool = False,
                                  search_ald: bool = False,
                                  pagination: bool = False) -> typing.Generator:
        server_controls = []
        attribute_list = None
        base_ou = base_ou if base_ou else self._root_dn
        if deletion:
            attribute_list = None
            server_controls.append(self.delcontr)
        if search_ald:
            attribute_list = ["+", "*", ]
        if pagination:
            page_control = SimplePagedResultsControl(True, size=1000,
                                                     cookie='')
            server_controls.append(page_control)

            try:
                is_last = False
                while True:
                    if is_last:
                        break
                    res = self._connect.search_ext(base_ou, ldap.SCOPE_SUBTREE,
                                                   filter_ldap,
                                                   attrlist=attribute_list,
                                                   serverctrls=server_controls)

                    rtype, rdata, rmsgid, serverctrls = self._connect.result3(
                        res)

                    if len(rdata) == 0:
                        logger.info('Нет объектов для синхронизации')
                        break

                    controls = [control for control in serverctrls
                                if control.controlType
                                == SimplePagedResultsControl.controlType]
                    if not controls:
                        logger.error('No controls')
                        break

                    if not controls[0].cookie:
                        is_last = True

                    page_control.cookie = controls[0].cookie
                    yield rdata

            except ldap.LDAPError as error:
                logger.error(error)
                raise

    def do_search(self,
                  base_ou: str = None,
                  filter_ldap: str = None,
                  deletion: bool = False,
                  search_ald: bool = False) -> List:
        """
        Searching for deleted, in ald,
         in ad (by default).
        return: List
        """
        base_ou = base_ou if base_ou else self._root_dn
        if search_ald:
            try:
                res = self._connect.search_s(base_ou, ldap.SCOPE_SUBTREE,
                                             filter_ldap, ["+", "*", ], 0)
                return res
            except ldap.LDAPError as error:
                logger.error(error)
                raise
        if deletion:
            try:
                res_id = self._connect.search_ext(
                    base_ou,
                    ldap.SCOPE_SUBTREE,
                    filter_ldap,
                    None,
                    serverctrls=[self.delcontr, ]
                )
                res = []
                while True:
                    result_type, result_data = self._connect.result(res_id, 0)
                    if result_type == ldap.RES_SEARCH_ENTRY:
                        res.append(result_data)
                    else:
                        break
            except ldap.LDAPError:
                raise
            return res
        res = self._connect.search_s(base_ou,
                                     ldap.SCOPE_SUBTREE,
                                     filter_ldap)
        return res

    def do_search_onelevel(self, root, filter_ldap) -> List:
        try:
            res = self._connect.search_s(root, ldap.SCOPE_ONELEVEL, filter_ldap)
        except ldap.LDAPError:
            raise
        return res

    def do_search_base(self, base_ou, filter_ldap) -> List:
        try:
            res = self._connect.search_s(base_ou, ldap.SCOPE_BASE, filter_ldap)
        except ldap.LDAPError:
            raise
        return res

    def do_insert_data(self, *args, **kwargs):
        pass

    def do_update_data(self, *args, **kwargs):
        return self._connect.modify_s(*args, **kwargs)

    def do_get_data(self, *args, **kwargs):
        pass

    def get_org_units(self, base_ou: str = None, deep: bool = True) -> List:
        """
        Return list names of hosts domain's replicas in AD
        """
        base_ou = base_ou if base_ou else self._root_dn
        if deep:
            result = self.do_search(base_ou=base_ou, filter_ldap=self.SEARCH_ORG_UNIT_FILTER)
        else:
            result = self.do_search_onelevel(root=base_ou, filter_ldap=self.SEARCH_ORG_UNIT_FILTER)
        return result

    def get_hosts_dc(self) -> List:
        """
        Return list names of hosts domain's replicas in ActiveDirectory
        """
        root_search_domain_controllers = f'{self.SEARCH_DC_DIRECTORY_NAME},{self._root_dn}'
        res = self.do_search_onelevel(
            root=root_search_domain_controllers,
            filter_ldap=self.SEARCH_DC_FILTER
        )
        hosts = [instance[1][self.NAMING_REPLICA_DOMAIN_KEY][0].decode().lower()
                 for instance in res if instance[1].get("cn", None)]
        return hosts


class ProviderAPIStrategy(ProviderStrategy):

    def __init__(self):
        self._connect = None

    def do_bind(self, options_bind: Dict) -> None:
        hosts = list()
        hosts.append(options_bind['host'])
        hosts.extend(options_bind['replica'])
        hosts = list(dict.fromkeys(hosts))
        for host in hosts:
            try:
                self._connect = Api(
                    host=host,
                    username=options_bind.get('user', None),
                    password=options_bind.get('password', None),
                    verify_ssl=False,
                )
                logger.debug(f"Connect to provider host {host} is successful. Protocol API")
            except Exception as e:
                logger.error(e)
                continue
            else:
                break
        else:
            raise NotConnectedToProvider(f'Not connect to provider {options_bind["host"]}. Protocol API')

    def do_unbind(self):
        pass

    @raise_for_status
    def request(self, *args, **kwargs):
        return self._connect.request(*args, **kwargs)

    def do_insert_data(self, *args, **kwargs):
        return self.request(*args, **kwargs)

    def do_update_data(self, *args, **kwargs):
        return self.request(*args, **kwargs)

    def do_get_data(self, *args, **kwargs):
        return self.request(*args, **kwargs)

    def get_hosts_dc(self):
        """
        Return list names of hosts domain's replicas in FreeIPA
        """
        pass

    def get_org_units(self, base_ou: str = None, deep: bool = True) -> List:
        """
        Return list names of organization units in domain's controller
        """
        logger.error(base_ou)
        result = self.request(
            method='orgunit_find',
            params={
                'parentou': base_ou,
                'deep': deep
            }
        )
        logger.error(result.text)
        if not result.status_code == 200:
            raise RequestException(f'{result.status_code}: {result.reason}')

        result = result.json()

        if result.get('error', None):
            raise RequestException(result.get('error'))

        units = list()
        for inst in result['result']['result']:
            s = inst['dn']
            inst['parentou'] = ','.join(s[:s.find(',cn=orgunits')].split(',')[1:])
            units.append(inst)
        return units

    def do_search(self, base_ou: str = None, deep: bool = True) -> List:
        """
        Return list names of organization units in domain's controller
        """
        result = self.request(
            method='orgunit_find',
            params={
                'parentou': base_ou,
                'deep': deep
            }
        )

        if not result.status_code == 200:
            raise RequestException(f'{result.status_code}: {result.reason}')

        result = result.json()

        if result.get('error', None):
            raise RequestException(result.get('error'))

        units = list()
        for inst in result['result']['result']:
            s = inst['dn']
            inst['parentou'] = ','.join(s[:s.find(',cn=orgunits')].split(',')[1:])
            units.append(inst)
        return units

    def do_search_deleted(self):
        pass

    def do_search_base(self):
        pass


class AD(ProviderLDAPStrategy):
    type_unit = "AD"
    name_unit = "LDAP"

    SEARCH_DC_DIRECTORY_NAME = 'OU=Domain Controllers'
    SEARCH_DC_FILTER = '(|(CN=*))'
    DEFAULT_NAMING_CONTEXT_KEY = 'defaultNamingContext'
    NAMING_REPLICA_DOMAIN_KEY = 'dNSHostName'

    def get_login(self, user, host):
        return user


class FreeIPA(ProviderLDAPStrategy):
    """
    Provide FreeIPA server use LDAP service
    """
    type_unit = "ALD"
    name_unit = "LDAP"

    SEARCH_DC_DIRECTORY_NAME = 'cn=masters,cn=ipa,cn=etc'
    SEARCH_DC_FILTER = '(|(CN=*))'
    DEFAULT_NAMING_CONTEXT_KEY = 'defaultnamingcontext'
    SEARCH_ORG_UNIT_FILTER = '(|(objectClass=rbta-org-unit))'


class FreeIPAApi(ProviderAPIStrategy):
    """
    Provide FreeIPA server use API service
    """
    type_unit = "ALD"
    name_unit = "API"


create_dict_strategies_classes()
