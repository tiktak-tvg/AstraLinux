from dataclasses import dataclass
from typing import Dict

from django.core.cache import cache
from options.models import ModelOptionsAuth
from options.serializers import SerializerBindOptions
from copy import deepcopy


@dataclass
class OptionsProvider:
    LDAPS: Dict
    HTTPS: Dict


@dataclass
class DataOptions:
    AD: OptionsProvider
    ALD: OptionsProvider


def get_options() -> DataOptions:
    """
    This method return class Options which
    contains options from auth scheme (ModelOptionsAuth)
    """
    options = cache.get('options')

    return options


def get_auth_options(auth: ModelOptionsAuth) -> dict:
    """
    This method return dict which
    contains options from auth scheme (ModelOptionsAuth)
    """
    return deepcopy(SerializerBindOptions(instance=auth).data)
