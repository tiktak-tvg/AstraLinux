try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup


import os.path

readme = ''
here = os.path.abspath(os.path.dirname(__file__))
readme_path = os.path.join(here, 'README.rst')
if os.path.exists(readme_path):
    with open(readme_path, 'rb') as stream:
        readme = stream.read().decode('utf8')


setup(
    long_description=readme,
    name='syncer',
    version='0.1.0',
    python_requires='==3.7.3',
    packages=['lib', 'logger', 'logger.migrations', 'options', 'options.migrations', 'provider', 'provider.migrations', 'provider.views', 'services.const', 'services.options.pass_encryption', 'syncer', 'tracer', 'tracer.migrations', 'tracer.views'],
    package_dir={"": "."},
    package_data={"options": ["config/*.example", "config/*.toml"]},
    install_requires=['colorlog==6.*,>=6.7.0', 'django==3.2.15', 'django-cors-headers==3.*,>=3.13.0', 'django-extensions==3.*,>=3.2.1', 'django-filter==22.*,>=22.1.0', 'djangorestframework==3.*,>=3.14.0', 'drf-spectacular==0.*,>=0.25.1', 'markdown==3.*,>=3.4.1', 'psycopg2-binary==2.*,>=2.9.5', 'python-dotenv==0.*,>=0.21.1', 'python-ldap==3.1.0', 'requests==2.*,>=2.28.2'],
)
