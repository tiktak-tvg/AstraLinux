import json
from pathlib import Path

from django.db import migrations, models

from syncer_options.models import ModelOptionsProviderType

BASE_DIR = Path(__file__).resolve().parent


def add_provider_type_to_db(apps, schema_editor):
    data = json.loads(
        open(BASE_DIR / 'data' / 'type.json').read()
    )
    codes = [ModelOptionsProviderType(**code) for code in data]
    ModelOptionsProviderType.objects.bulk_create(codes, ignore_conflicts=True)


class Migration(migrations.Migration):

    dependencies = [
        ('syncer_options', '0001_initial'),
    ]

    operations = [
        migrations.RunPython(add_provider_type_to_db),
        migrations.AlterField(
            model_name='modeloptionsauth',
            name='host',
            field=models.TextField(blank=False, default=None, unique=True, verbose_name='host'),
        ),
    ]
