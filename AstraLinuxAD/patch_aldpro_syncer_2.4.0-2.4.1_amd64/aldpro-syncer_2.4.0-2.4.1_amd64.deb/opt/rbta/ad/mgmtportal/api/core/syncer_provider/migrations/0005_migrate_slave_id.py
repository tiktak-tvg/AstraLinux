import logging

import ldap
import ldap.filter
from django.db import migrations

from syncer_options.models import ModelOptionsAuth
from syncer_provider.models import ModelVirtualTreeLDAP
from syncer_services.options.options import get_auth_options
from syncer_services.provider.provider import Provider
from syncer_services.provider.strategy import ProviderStrategiesDict

logger = logging.getLogger("syncer_migrations")

BATCH_SIZE = 1000


def get_parent_dn(guid: str) -> [str, None]:
    """Поиск части DN объекта по GUID из виртуального дерева
    Args:
        guid (str): master_i_d объекта в виртуальном дереве
    Return:
        (str): часть DN объекта
    """
    result = []
    if not guid:
        return None
    while True:
        parent = ModelVirtualTreeLDAP.objects.filter(master_i_d=guid).first()
        if not parent:
            break
        if parent.execute:
            result.append(f"ou={parent.object_name}")
        else:
            result.append(f"ou={parent.object_name_new}")
        guid = parent.parent
    if result:
        return ",".join(filter(None, result))
    else:
        return None


def replace_quotes(s: str) -> str:
    """Замена кавычек в строке

    Args:
        s (str): строка для замены

    Returns:
        (str): замененная строка
    """
    return s.replace('"', "\\\\22")


def create_update_org_units(units: list, data: dict) -> list:
    """Подготовка QuerySet орг юнитов для сохранения в БД

    Args:
        units (QuerySet): объкты для модификации
        data (dict): словарь данных для модификации объектов

    Returns:
        update_data (QuerySet): объекты для сохранения в БД
    """
    result = dict()
    update_data = list()
    for key, value in data.items():
        try:
            result[value["id"]] = value["slave_i_d"]
        except KeyError:
            continue
    for unit in units:
        try:
            unit.slave_i_d = result[unit.pk]
            update_data.append(unit)
        except KeyError:
            logger.warning(f"Не мигрирован slave_i_d для объекта с id={unit.pk}")
            continue
    return update_data


def migrate_slave_id_org_units(
    units: ModelVirtualTreeLDAP.objects, provider: Provider, batch_size: int = BATCH_SIZE
) -> list:
    """Миграция орг юнитов
    Args:
        units (QuerySet): список орг юнитов
        provider (Provider): провайдер АЛД ЛДАП для взаимодействия с АЛД
        batch_size: количество объектов для итерации модификации

    Returns:
        (QuerySet): список измененных объектов для сохранения в БД
    """

    data: dict = dict()
    counts = units.count()
    units = list(units)
    batch_count = 0
    for i in range(0, len(units), batch_size):
        ldap_filter = list()
        for unit in units[i : i + batch_size]:
            parent_dn = get_parent_dn(unit.master_i_d)
            dn = ",".join([parent_dn, unit.structure_i_d.dn_rx])
            dn = replace_quotes(dn)
            ldap_filter.append(f"(entrydn={ldap.filter.escape_filter_chars(dn)})")
            data[dn.lower()] = {"id": unit.pk}
            batch_count += 1
        ldap_filter = "".join(ldap_filter)
        ldap_filter = f"(|{ldap_filter})"
        ldap_result = provider.strategy._connect.search_s(
            provider.strategy._root_dn,
            ldap.SCOPE_SUBTREE,
            ldap_filter,
            ["nsUniqueId", "entrydn"],
        )
        if not ldap_result:
            logger.warning(f"Пустой ответ от ЛДАП на фильтр: {ldap_filter}")
        for result in ldap_result:
            data[result[1]["entrydn"][0].decode().replace("\\", "\\\\")]["slave_i_d"] = result[1]["nsUniqueId"][
                0
            ].decode()
        if batch_count % 100 == 0:
            logger.info(f"Обработанно {batch_count}/{counts} подразделений")
    return create_update_org_units(units=units, data=data)


def migrate_slave_id_units(
    units: ModelVirtualTreeLDAP.objects, provider: Provider, batch_size: int = BATCH_SIZE
) -> list:
    """Миграция юзеров и групп
    Args:
        units (QuerySet): список юзеров и групп
        provider (Provider): провайдер АЛД ЛДАП для взаимодействия с АЛД
        batch_size: количество объектов для итерации модификации

    Returns:
        (QuerySet): список измененных объектов для сохранения в БД
    """

    update_data = list()
    units_unique_id_dict: dict = dict()
    all_counts = units.count()
    batch_counts = 0
    units = list(units)
    for i in range(0, len(units), batch_size):
        ldap_filter = list()
        for unit in units[i : i + batch_size]:
            ldap_filter.append(f"(ipaUniqueId={unit.slave_i_d})")
            batch_counts += 1

        ldap_filter = f"(|{''.join(ldap_filter)})"
        ldap_result = provider.strategy._connect.search_s(
            provider.strategy._root_dn,
            ldap.SCOPE_SUBTREE,
            ldap_filter,
            ["nsUniqueId", "ipaUniqueId"],
        )
        if not ldap_result:
            logger.warning(f"Пустой ответ от ЛДАП на фильтр: {ldap_filter}")
        units_unique_id_dict.update(
            {
                ldap_unit[1]["ipaUniqueId"][0].decode(): ldap_unit[1]["nsUniqueId"][0].decode()
                for ldap_unit in ldap_result
            }
        )
        if batch_counts % 1000 == 0:
            logger.info(f"Выгружено {batch_counts}/{all_counts} пользователей и групп из АЛД")

    for unit in units:
        if units_unique_id_dict.get(unit.slave_i_d, None) is None:
            logger.error(f"Не найден {unit.slave_i_d} в АЛД")
            unit.slave_i_d = None
        else:
            unit.slave_i_d = units_unique_id_dict[unit.slave_i_d]
        update_data.append(unit)
    return update_data


def migrate_members_in_group(units: ModelVirtualTreeLDAP.objects) -> list:
    """Миграция мемберов в группах. Замена object_name на slave_i_d
    Args:
        units (QuerySet): группы для миграции мемберов

    Returns:
        None
    """
    all_users = ModelVirtualTreeLDAP.objects.filter(slave_i_d__isnull=False, object_class__key="user").values(
        "object_name", "master_i_d"
    )
    all_groups = ModelVirtualTreeLDAP.objects.filter(slave_i_d__isnull=False, object_class__key="group").values(
        "object_name", "master_i_d"
    )
    all_users = {user["object_name"]: user["master_i_d"] for user in all_users}
    all_groups = {group["object_name"]: group["master_i_d"] for group in all_groups}
    update_data = list()
    units = units.values("id", "master_attributes", "master_i_d")
    counts = len(units)
    for number, unit in enumerate(units, 1):
        members = unit["master_attributes"].get("member", {})
        if members:
            unit["master_attributes"]["member"] = dict()
        else:
            continue
        groups = members if isinstance(members, list) else members.get("group", [])
        if groups:
            groups = [all_groups[group] for group in groups if all_groups.get(group)]
            unit["master_attributes"]["member"]["group"] = groups

        users = members if isinstance(members, list) else members.get("user", [])
        if users:
            users = [all_users[user] for user in users if all_users.get(user)]
            unit["master_attributes"]["member"]["user"] = users
        update_data.append(ModelVirtualTreeLDAP(**unit))
        if number % 1000 == 0:
            logger.info(f"Обработано групп {number}/{counts}")
    return update_data


def migrate_slave_id(apps, schema_editor):
    """Функция миграции орг юнитов, юзеров, групп"""
    logger.info("Начало миграции")

    if not ModelVirtualTreeLDAP.objects.all().defer("pwdlastset", "krblastpwdchange"):
        logger.info("Нет объектов для миграции")
        return

    auth = ModelOptionsAuth.objects.filter(type__type="ALD").first()
    if auth is None:
        return
    option_value = get_auth_options(auth)
    provider = Provider(ProviderStrategiesDict[option_value["type"]]["LDAP"]())
    logger.info("Подключение к АЛД")
    provider.bind(option_value)
    logger.info("Подключение к АЛД успешно")

    units = ModelVirtualTreeLDAP.objects.filter(object_class__key="organizationalUnit").order_by("id")
    logger.info(f"Миграция подразделений. Количество объектов: {units.count()}")
    update_data = migrate_slave_id_org_units(units, provider, batch_size=1)
    logger.info("Обновление slave_i_d для подразделений в БД")
    ModelVirtualTreeLDAP.objects.bulk_update(update_data, ["slave_i_d"])
    logger.info("slave_i_d для подразделений мигрирован успешно")

    units = ModelVirtualTreeLDAP.objects.filter(
        slave_i_d__isnull=False, object_class__key__in=["user", "group"]
    ).order_by("id")
    logger.info(f"Миграция пользователей и групп. Количество объектов: {units.count()}")
    migrate_slave_id_units(units, provider, batch_size=1)
    logger.info("Обновление slave_i_d для пользователей и групп в БД")
    ModelVirtualTreeLDAP.objects.bulk_update(units, ["slave_i_d"], batch_size=10_000)
    logger.info("slave_i_d для пользователей и групп мигрирован успешно")

    units = ModelVirtualTreeLDAP.objects.filter(slave_i_d__isnull=False, object_class__key="group")
    logger.info(f"Миграция мемберов для групп. Количество групп: {units.count()}")
    update_data = migrate_members_in_group(units)
    logger.info("Обновление мемберов для групп в БД")
    ModelVirtualTreeLDAP.objects.bulk_update(update_data, ["master_attributes"], batch_size=10_000)
    logger.info("Мемберы для групп мигрированы успешно")
    logger.info("Миграция завершена")


class Migration(migrations.Migration):
    dependencies = [
        ("syncer_provider", "0004_alter_modelprovidertxrx_unique_together"),
    ]

    operations = [
        migrations.RunPython(migrate_slave_id),
    ]
