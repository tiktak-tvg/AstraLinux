from django.db import migrations

from syncer_options.models import ModelOptionsProviderType, ModelOptionsAuth

from django.conf import settings


SETTINGS_LIST = ['SYNCER_ALDPRO_CA_PATH','SYNCER_ALDPRO_LOGIN','SYNCER_ALDPRO_PASSWD','SYNCER_ALDPRO_SERVER']

def add_aldpro_connection(apps, schema_editor):
    
    if all(list(map(lambda x: getattr(settings, x), SETTINGS_LIST))):  
        
        with open(settings.SYNCER_ALDPRO_CA_PATH, "r") as file:          
            ca_cert = file.read()
            
        aldpro_type = ModelOptionsProviderType.objects.get(type="ALD")
        
        defaults = {"user": settings.SYNCER_ALDPRO_LOGIN,
                    "password": settings.SYNCER_ALDPRO_PASSWD,
                    "key": ca_cert}
        try:
            obj = ModelOptionsAuth.objects.get(host=settings.SYNCER_ALDPRO_SERVER)
            for key, value in defaults.items():
                setattr(obj, key, value)
                obj.save()
        except ModelOptionsAuth.DoesNotExist:
            new_values = {"host": settings.SYNCER_ALDPRO_SERVER,
                    "user": settings.SYNCER_ALDPRO_LOGIN,
                    "password": settings.SYNCER_ALDPRO_PASSWD,
                    "key": ca_cert,
                    "type": aldpro_type}

            obj = ModelOptionsAuth(**new_values)
            obj.save()
    

class Migration(migrations.Migration):

    dependencies = [
        ('syncer_options', '0002_alter_modeloptionsauth_host'),
    ]

    operations = [
        migrations.RunPython(add_aldpro_connection)
    ]
