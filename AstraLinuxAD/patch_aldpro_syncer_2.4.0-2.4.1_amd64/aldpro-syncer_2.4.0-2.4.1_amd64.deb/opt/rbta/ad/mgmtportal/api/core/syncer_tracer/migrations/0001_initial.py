import django.db.models.deletion
from django.db import migrations, models

TRACER_OBJECTS = """
INSERT INTO schema_tracer.tracer_objects (id,name,"key") VALUES
    (14,'Группа','group'),
    (15,'Пользователь','user'),
    (16,'Подразделение','organizationalUnit');
"""


TRACER_ATTRIBUTE_ALD_SQL = """
INSERT INTO schema_tracer.tracer_attribute_aldpro (id,name,"key") VALUES
    (12,'sn','sn'),
    (17,'givenname','givenname'),
    (20,'userParameters','userParameters'), 
    (21,'nsaccountlock','nsaccountlock');
"""

TRACER_ATTRIBUTE_AD_SQL = """
INSERT INTO schema_tracer.tracer_attribute_ad (id,name,"key") VALUES
    (11,'sn','sn'),
    (16,'givenName','givenName'),
    (21,'userParameters','userParameters'),
    (22,'userAccountControl','userAccountControl');
"""

TRACER_SQL = """
INSERT INTO schema_tracer.tracer (key_ad_id,key_ald_id,object_class_id) VALUES
    (11,12,15),
    (16,17,15),
    (21,20,15),
    (22,21,15);
"""
MAX_ID_SQL = """
    BEGIN;
    SELECT setval(pg_get_serial_sequence('"schema_tracer"."tracer_objects"','id'), coalesce(max("id"), 1), max("id") IS NOT null) FROM "schema_tracer"."tracer_objects";
    SELECT setval(pg_get_serial_sequence('"schema_tracer"."tracer_attribute_aldpro"','id'), coalesce(max("id"), 1), max("id") IS NOT null) FROM "schema_tracer"."tracer_attribute_aldpro";
    SELECT setval(pg_get_serial_sequence('"schema_tracer"."tracer_attribute_ad"','id'), coalesce(max("id"), 1), max("id") IS NOT null) FROM "schema_tracer"."tracer_attribute_ad";
    SELECT setval(pg_get_serial_sequence('"schema_tracer"."tracer"','id'), coalesce(max("id"), 1), max("id") IS NOT null) FROM "schema_tracer"."tracer";
    COMMIT;
"""

class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='ModelTracerAttributesAD',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=255, verbose_name='name')),
                ('key', models.CharField(blank=True, default=None, max_length=255, null=True, verbose_name='key')),
            ],
            options={
                'verbose_name': 'Атрибуты полей AD',
                'verbose_name_plural': 'Атрибуты полей AD',
                'db_table': 'schema_tracer"."tracer_attribute_ad',
            },
        ),
        migrations.CreateModel(
            name='ModelTracerAttributesALDPro',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=255, verbose_name='name')),
                ('key', models.CharField(blank=True, default=None, max_length=255, null=True, verbose_name='key')),
            ],
            options={
                'verbose_name': 'Атрибуты полей ALDPro',
                'verbose_name_plural': 'Атрибуты полей ALDPro',
                'db_table': 'schema_tracer"."tracer_attribute_aldpro',
            },
        ),
        migrations.CreateModel(
            name='ModelTracerObjectClass',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=255, verbose_name='name')),
                ('key', models.CharField(blank=True, default=None, max_length=255, null=True, verbose_name='key')),
            ],
            options={
                'verbose_name': 'Класс',
                'verbose_name_plural': 'Класс',
                'db_table': 'schema_tracer"."tracer_objects',
            },
        ),
        migrations.CreateModel(
            name='ModelTracer',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('key_ad', models.ForeignKey(default=None, on_delete=django.db.models.deletion.CASCADE, to='syncer_tracer.modeltracerattributesad', verbose_name='key_ad')),
                ('key_ald', models.ForeignKey(default=None, on_delete=django.db.models.deletion.CASCADE, to='syncer_tracer.modeltracerattributesaldpro', verbose_name='key_ald')),
                ('object_class', models.ForeignKey(default=None, on_delete=django.db.models.deletion.CASCADE, to='syncer_tracer.modeltracerobjectclass', verbose_name='object_class')),
            ],
            options={
                'verbose_name': 'Tracer атрибутов',
                'verbose_name_plural': 'Tracer атрибутов',
                'db_table': 'schema_tracer"."tracer',
            },
        ),
        migrations.RunSQL(TRACER_OBJECTS),
        migrations.RunSQL(TRACER_ATTRIBUTE_AD_SQL),
        migrations.RunSQL(TRACER_ATTRIBUTE_ALD_SQL),
        migrations.RunSQL(TRACER_SQL),
        migrations.RunSQL(MAX_ID_SQL),
    ]
